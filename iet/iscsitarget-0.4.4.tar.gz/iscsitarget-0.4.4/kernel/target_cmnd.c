/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/pagemap.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "iotype.h"

static kmem_cache_t *target_cmnd_cache;

struct target_cmnd *target_cmnd_alloc(void)
{
	struct target_cmnd *tcmnd;
	do {
		tcmnd = kmem_cache_alloc(target_cmnd_cache, GFP_KERNEL);
		if (!tcmnd)
			yield();
	} while (!tcmnd);

	dprintk(D_GENERIC, "%p\n", tcmnd);
	memset(tcmnd, 0, sizeof(*tcmnd));

	return tcmnd;
}

static inline void target_cmnd_free(struct target_cmnd *tcmnd)
{
	kmem_cache_free(target_cmnd_cache, tcmnd);
}

int target_alloc_pages(struct target_cmnd *tcmnd, int count)
{
	int i;
	struct page *page;

	dprintk(D_GENERIC, "%p %d (%d)\n", tcmnd, count, tcmnd->pg_cnt);

	assert(!tcmnd->pvec);
	tcmnd->pg_cnt = count;

	count *= sizeof(struct page *);

	do {
		if ((tcmnd->pvec = kmalloc(count, GFP_KERNEL)) == NULL)
			yield();
	} while (!tcmnd->pvec);

	memset(tcmnd->pvec, 0, count);

	for (i = 0; i < tcmnd->pg_cnt; i++) {
		do {
			if (!(page = alloc_page(GFP_KERNEL)))
				yield();
		} while (!page);

		tcmnd->pvec[i] = page;
	}
	return 0;
}

void target_free_pages(struct target_cmnd *tcmnd)
{
	int i;

	if (!tcmnd)
		return;
	dprintk(D_GENERIC, "%p %d\n", tcmnd, tcmnd->pg_cnt);

	for (i = 0; i < tcmnd->pg_cnt; i++) {
		assert(tcmnd->pvec[i]);
		__free_page(tcmnd->pvec[i]);
	}
	kfree(tcmnd->pvec);
	target_cmnd_free(tcmnd);
}

void target_init_iocmnd(struct target_cmnd *tcmnd, loff_t offset, u32 size)
{
	tcmnd->idx = offset >> PAGE_CACHE_SHIFT;
	tcmnd->offset = offset & ~PAGE_CACHE_MASK;
	tcmnd->size = size;

	tcmnd->pg_cnt = (size + tcmnd->offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
}

int target_read_pages(struct iet_volume *lu, struct target_cmnd *tcmnd)
{
	struct iotype *iot = lu->iotype;
	assert(iot);
	return iot->make_request(lu, tcmnd, READ);
}

int target_commit_pages(struct iet_volume *lu, struct target_cmnd *tcmnd)
{
	struct iotype *iot = lu->iotype;
	assert(iot);
	return iot->make_request(lu, tcmnd, WRITE);
}

int target_sync_pages(struct iet_volume *lu, struct target_cmnd *tcmnd)
{
	struct iotype *iot = lu->iotype;
	assert(iot);
	return iot->sync(lu, tcmnd);
}

int target_init(void)
{
	target_cmnd_cache = kmem_cache_create("target_cmnd",
					      sizeof(struct target_cmnd), 0, 0, NULL, NULL);
	return  target_cmnd_cache ? 0 : -ENOMEM;
}

void target_exit(void)
{
	kmem_cache_destroy(target_cmnd_cache);
}
