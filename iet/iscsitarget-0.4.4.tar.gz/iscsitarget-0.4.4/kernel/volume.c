/*
 * Volume manager
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "iotype.h"

struct iet_volume *iet_volume_lookup(struct iscsi_target *target, u32 lun)
{
	struct iet_volume *volume;

	list_for_each_entry(volume, &target->volumes, list) {
		if (volume->lun == lun)
			return volume;
	}
	return NULL;
}

int iet_volume_add(struct iscsi_target *target, struct volume_info *info)
{
	int res = 0;
	struct iotype *iot;
	struct iet_volume *volume;

	volume = iet_volume_lookup(target, info->lun);

	if (volume)
		return -EEXIST;

	if (strlen(info->mode) <= 0 || (iot = get_iotype(info->mode)) == NULL)
		return -EINVAL;

	if (info->lun > 0x3fff)
		return -EINVAL;

	volume = kmalloc(sizeof(*volume), GFP_KERNEL);
	if (!volume)
		return -ENOMEM;
	memset(volume, 0, sizeof(*volume));

	volume->target = target;
	volume->lun = info->lun;
	volume->dev = MKDEV(info->major, info->minor);
	volume->iotype = iot;

	INIT_LIST_HEAD(&volume->queue.wait_list);
	spin_lock_init(&volume->queue.queue_lock);

	if ((res = iot->attach(volume, info->path)) < 0)
		goto err;

	list_add_tail(&volume->list, &target->volumes);
	atomic_inc(&target->nr_volumes);

	return res;

err:
	if (volume) {
		put_iotype(iot);
		kfree(volume);
	}

	return res;
}

int iet_volume_del(struct iet_volume *volume)
{
	volume->iotype->detach(volume);
	put_iotype(volume->iotype);
	list_del(&volume->list);

	kfree(volume);

	return 0;
}

static void iet_volume_info_show(struct seq_file *seq, struct iscsi_target *target)
{
	struct iet_volume *volume;

	list_for_each_entry(volume, &target->volumes, list) {
		seq_printf(seq, "\tlun:%u major:%x minor:%x iotype:%s\n", volume->lun,
			   MAJOR(volume->dev), MINOR(volume->dev), volume->iotype->name);
	}
}

static int iet_volumes_info_show(struct seq_file *seq, void *v)
{
	return iet_info_show(seq, iet_volume_info_show);
}

static int iet_volume_seq_open(struct inode *inode, struct file *file)
{
	return single_open(file, iet_volumes_info_show, NULL);
}

struct file_operations volume_seq_fops = {
	.owner		= THIS_MODULE,
	.open		= iet_volume_seq_open,
	.read		= seq_read,
	.llseek		= seq_lseek,
	.release	= single_release,
};
