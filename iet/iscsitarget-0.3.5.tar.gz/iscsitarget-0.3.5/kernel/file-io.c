/*
 * Target device file I/O.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <linux/blkdev.h>
#include <asm/uaccess.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "iotype.h"

MODULE_AUTHOR("Fujita Tomonori <tomof@acm.org>");
MODULE_DESCRIPTION("iSCSI Target file I/O");
MODULE_LICENSE("GPL");

struct fileio_data {
	struct file *filp;
};

int fileio_make_request(struct iet_volume *lu, struct target_cmnd *tcmnd, int rw)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;
	struct file *filp;
	mm_segment_t oldfs;
	struct page *page;
	unsigned long pg_idx;
	u32 pg_nr, pg_cnt, offset, size;
	loff_t ppos, count;
	char *buf;
	int i, j, tcmnd_nr, nr;
	ssize_t ret;

	assert(p);
	filp = p->filp;
	size = tcmnd->u.pg.size;
	offset= tcmnd->u.pg.offset;

	pg_idx = tcmnd->u.pg.idx;
	pg_nr = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	tcmnd_nr = (pg_nr + TARGET_CMND_MAX_PAGES - 1) / TARGET_CMND_MAX_PAGES;

	ppos = (loff_t) pg_idx << PAGE_CACHE_SHIFT;
	ppos += offset;
	assert(tcmnd->u.pg.pos == (u32) ppos);

	pg_cnt = pg_nr;
	for (i = 0; i < tcmnd_nr; i++) {
		assert(tcmnd);
		if (i == tcmnd_nr - 1)
			nr = (pg_nr % TARGET_CMND_MAX_PAGES) ? : TARGET_CMND_MAX_PAGES;
		else
			nr = TARGET_CMND_MAX_PAGES;

		for (j = 0; j < nr; j++) {
			page = tcmnd->u.pg.io_pages[j];
			assert(page);
			buf = page_address(page);
			buf += offset;

			if (offset + size > PAGE_SIZE)
				count = PAGE_SIZE - offset;
			else
				count = size;

			oldfs = get_fs();
			set_fs(get_ds());

			if (rw == READ)
				ret = generic_file_read(filp, buf, count, &ppos);
			else
				ret = generic_file_write(filp, buf, count, &ppos);

			set_fs(oldfs);

			if (ret != count)
				printk("%s(%d) Bad things happened %lld, %ld\n",
				       __FUNCTION__, __LINE__, count, (long) ret);

			size -= count;
			offset = 0;
		}
		pg_cnt -= nr;
		tcmnd = tcmnd->next;
	}
	assert(!size);
	assert(!pg_cnt);

	return 0;
}

static inline void walk_pages(struct target_cmnd *tcmnd, struct address_space *mapping,
			      int (*fn)(struct page *))
{
	struct page *page;
	unsigned long i, pg_idx;
	unsigned int pg_nr;
	int res;

	pg_idx = tcmnd->u.pg.idx;
	pg_nr = (tcmnd->u.pg.size + tcmnd->u.pg.offset + PAGE_SIZE - 1) >> PAGE_SHIFT;

	for (i = 0; i < pg_nr; i++) {
		page = find_lock_page(mapping, pg_idx + i);
		if (!page)
			continue;

		if (page->buffers) {
			dprintk(D_IOMODE, "write %d %lu %lu %lx\n",
				current->pid, i, page->index, page->flags);

			res = fn(page);
			if (res < 0)
				printk("%s(%d) %lu %d\n",
				       __FUNCTION__, __LINE__, page->index, res);
		}

		unlock_page(page);
		page_cache_release(page);
	}
}

int fileio_sync(struct iet_volume *lu, struct target_cmnd *tcmnd)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;
	struct address_space *mapping;

	assert(p);
	mapping = p->filp->f_dentry->d_inode->i_mapping;

	walk_pages(tcmnd, mapping, writeout_one_page);
	walk_pages(tcmnd, mapping, waitfor_one_page);

	return 0;
}

int fileio_attach(struct iet_volume *lu, char *path)
{
	int res = 0;
	struct fileio_data *p;
	struct file *filp;
	mm_segment_t oldfs;
	kdev_t kdev;
	struct inode *inode;

	if (lu->private) {
		printk("already attached ? %d\n", lu->lun);
		return -EBUSY;
	}

	p = kmalloc(sizeof(*p), GFP_KERNEL);
	if (!p)
		return -ENOMEM;

	oldfs = get_fs();
	set_fs(get_ds());
	filp = filp_open(path, O_RDWR|O_LARGEFILE, 0);
	set_fs(oldfs);
	if (IS_ERR(filp)) {
		printk("%s(%d) can't open %s\n", __FUNCTION__, __LINE__, path);
		res = PTR_ERR(filp);
		goto fail;
	}

	inode = filp->f_dentry->d_inode;
	lu->blk_shift = 9;
	if (S_ISREG(inode->i_mode)) {
		lu->blk_cnt = inode->i_size >> 10;
	} else if (S_ISBLK(inode->i_mode)) {
		kdev = inode->i_rdev;
		if (!blk_size[MAJOR(kdev)]) {
			printk("%s(%d) blk_size[kdev] is null\n", __FUNCTION__, __LINE__);
			filp_close(filp, NULL);
			res = -ENODEV;
			goto fail;
		}
		lu->blk_cnt = blk_size[MAJOR(kdev)][MINOR(kdev)];
	} else {
		printk("%s(%d) %s is not a block file\n", __FUNCTION__, __LINE__, path);
		filp_close(filp, NULL);
		res = -EINVAL;
		goto fail;
	}

	if (lu->blk_shift < 10)
		lu->blk_cnt <<= 10 - lu->blk_shift;
	else
		lu->blk_cnt >>= lu->blk_shift - 10;

	p->filp = filp;

	lu->private = p;

	return res;
fail:
	kfree(p);
	return res;
}

void fileio_detach(struct iet_volume *lu)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;

	assert(p);
	filp_close(p->filp, NULL);
	kfree(p);
	lu->private = NULL;
}

static struct iotype fileio =
{
	.name = "fileio",
	.owner = THIS_MODULE,
	.attach = fileio_attach,
	.make_request = fileio_make_request,
	.sync = fileio_sync,
	.detach = fileio_detach,
};

static int __init init_fileio(void)
{
	int res;

	res = register_iotype(&fileio);
	if (!res)
		printk("%s(%d) register %s\n", __FUNCTION__, __LINE__, fileio.name);
	else
		printk("%s(%d) failed to register %s\n", __FUNCTION__, __LINE__, fileio.name);

	return res;
}

static void __exit exit_fileio(void)
{
	printk("%s(%d) unregister %s\n", __FUNCTION__, __LINE__, fileio.name);
	unregister_iotype(&fileio);
}

EXPORT_NO_SYMBOLS;

module_init(init_fileio);
module_exit(exit_fileio);
