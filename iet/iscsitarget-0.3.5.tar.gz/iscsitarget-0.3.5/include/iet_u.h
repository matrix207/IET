#ifndef _IET_U_H
#define _IET_U_H

#define IET_VERSION_STRING	"0.3.5"

/* The maximum length of 223 bytes in the RFC. */
#define ISCSI_NAME_LEN	256

struct target_info {
	u32 tid;
	char name[ISCSI_NAME_LEN];

	u32 nr_wthreads;
};

struct volume_info {
	u32 tid;

	u32 lun;
	u32 major;
	u32 minor;
	char path[ISCSI_NAME_LEN];
	char mode[ISCSI_NAME_LEN];
};

struct session_info {
	u32 tid;

	u64 sid;
	char initiator_name[ISCSI_NAME_LEN];
	u32 exp_cmd_sn;
	u32 max_cmd_sn;
};

struct conn_info {
	u32 tid;
	u64 sid;

	u32 cid;
	u32 stat_sn;
	u32 exp_stat_sn;
	int fd;
};

struct param_info {
	u32 tid;
	u64 sid;

	u32 is_target_param;

	u32 flags;
	u32 max_connections;
	u32 max_data_pdu_length;
	u32 max_burst_length;
	u32 first_burst_length;
	u32 default_wait_time;
	u32 default_retain_time;
	u32 max_outstanding_r2t;
	u32 error_recovery_level;
};

enum iet_event_state {
	E_CONN_CLOSE,
};

struct iet_event {
	u32 tid;
	u64 sid;
	u32 cid;
	u32 state;
};

#define ADD_TARGET _IOW('i', 0, struct target_info)
#define DEL_TARGET _IOW('i', 1, struct target_info)
#define START_TARGET _IO('i', 2)
#define STOP_TARGET _IO('i', 3)
#define ADD_VOLUME _IOW('i', 4, struct volume_info)
#define DEL_VOLUME _IOW('i', 5, struct volume_info)
#define ADD_SESSION _IOW('i', 6, struct session_info)
#define DEL_SESSION _IOW('i', 7, struct session_info)
#define GET_SESSION_INFO _IOWR('i', 8, struct session_info)
#define ADD_CONN _IOW('i', 9, struct conn_info)
#define DEL_CONN _IOW('i', 10, struct conn_info)
#define GET_CONN_INFO _IOWR('i', 11, struct conn_info)
#define ISCSI_PARAM_SET _IOW('i', 12, struct param_info)
#define ISCSI_PARAM_GET _IOWR('i', 13, struct param_info)

#endif
