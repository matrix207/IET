/*
 * Network thread.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/sched.h>
#include <linux/file.h>
#include <linux/kthread.h>
#include <asm/ioctls.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"
#include "digest.h"

DECLARE_WAIT_QUEUE_HEAD(iscsi_ctl_wait);

enum daemon_state_bit {
	D_ACTIVE,
	D_DATA_READY,
};

void wake_up_nthread(struct iscsi_target *target)
{
	struct network_thread_info *info = &target->nthread_info;

	spin_lock_bh(&info->nthread_lock);
	set_bit(D_DATA_READY, &info->flags);
	wake_up_process(info->task);
	spin_unlock_bh(&info->nthread_lock);
}

static inline void iscsi_conn_init_read(struct iscsi_conn *conn, void *data, size_t len)
{
	len = (len + 3) & -4; // XXX ???
	conn->read_iov[0].iov_base = data;
	conn->read_iov[0].iov_len = len;
	conn->read_msg.msg_iov = conn->read_iov;
	conn->read_msg.msg_iovlen = 1;
	conn->read_size = (len + 3) & -4;
}

static void iscsi_conn_read_ahs(struct iscsi_conn *conn, struct iscsi_cmnd *cmnd)
{
	cmnd->pdu.ahs = kmalloc(cmnd->pdu.ahssize, __GFP_NOFAIL|GFP_KERNEL);
	assert(cmnd->pdu.ahs);
	iscsi_conn_init_read(conn, cmnd->pdu.ahs, cmnd->pdu.ahssize);
}

static struct iscsi_cmnd * iscsi_get_send_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd = NULL;

	spin_lock(&conn->list_lock);
	if (!list_empty(&conn->write_list)) {
		cmnd = list_entry(conn->write_list.next, struct iscsi_cmnd, list);
		list_del_init(&cmnd->list);
	}
	spin_unlock(&conn->list_lock);

	return cmnd;
}

static int is_data_available(struct iscsi_conn *conn)
{
	int avail, res;
	mm_segment_t oldfs;
	struct socket *sock = conn->sock;

	oldfs = get_fs();
	set_fs(get_ds());
	res = sock->ops->ioctl(sock, SIOCINQ, (unsigned long) &avail);
	set_fs(oldfs);
	return (res >= 0) ? avail : res;
}

static void forward_iov(struct msghdr *msg, int len)
{
	while (msg->msg_iov->iov_len <= len) {
		len -= msg->msg_iov->iov_len;
		msg->msg_iov++;
		msg->msg_iovlen--;
	}

	msg->msg_iov->iov_base = (char *) msg->msg_iov->iov_base + len;
	msg->msg_iov->iov_len -= len;
}

int do_recv(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	mm_segment_t oldfs;
	struct msghdr msg;
	struct iovec iov[ISCSI_CONN_IOV_MAX];
	int i, len, res;

	msg.msg_iov = iov;
	msg.msg_iovlen = min_t(size_t, conn->read_msg.msg_iovlen, ISCSI_CONN_IOV_MAX);
	for (i = 0, len = 0; i < msg.msg_iovlen; i++) {
		iov[i] = conn->read_msg.msg_iov[i];
		len += iov[i].iov_len;
	}

	oldfs = get_fs();
	set_fs(get_ds());
	res = sock_recvmsg(conn->sock, &msg, len, MSG_DONTWAIT | MSG_NOSIGNAL);
	set_fs(oldfs);

	if (res > 0) {
		conn->read_size -= res;
		if (conn->read_size)
			forward_iov(&conn->read_msg, res);
	}

	dprintk(D_IOD, "%d\n", res);

	return res;
}

int exec_cmnd_nio(struct iscsi_cmnd *cmnd)
{
	assert(cmnd->nio_idx);
	cmnd->nio_idx--;
	return cmnd->nios[cmnd->nio_idx](cmnd);
}

void add_cmnd_nio(struct iscsi_cmnd *cmnd, nio_func_t *nio)
{
	if (cmnd->nio_idx == MAX_NIOS)
		BUG();

	cmnd->nios[cmnd->nio_idx] = nio;
	cmnd->nio_idx++;
}

static int is_retry(int res)
{
	if (res > 0)
		return 1;
	else if (res == -EAGAIN || res == -EINTR)
		return 1;
	else
		return 0;
}

int end_rx_ddigest(struct iscsi_cmnd *cmnd)
{
	int res;

	res = digest_rx_data(cmnd);

	return !res ? 1 : res;
}

int rx_ddigest(struct iscsi_cmnd *cmnd)
{
	int res;

	res = do_recv(cmnd);

	if (is_retry(res) && cmnd->conn->read_size)
		add_cmnd_nio(cmnd, rx_ddigest);

	return res;
}

int init_rx_ddigest(struct iscsi_cmnd *cmnd)
{
	iscsi_conn_init_read(cmnd->conn, &cmnd->ddigest, sizeof(u32));
	return 1;
}

int rx_data(struct iscsi_cmnd *cmnd)
{
	int res;

	res = do_recv(cmnd);

	if (is_retry(res) && cmnd->conn->read_size)
		add_cmnd_nio(cmnd, rx_data);

	return res;
}

int init_rx_data(struct iscsi_cmnd *cmnd)
{
	cmnd->state = ISCSI_STATE_START;
	iscsi_cmnd_start_read(cmnd);

	if (cmnd->pdu.datasize) {
		if (cmnd->conn->ddigest_type != DIGEST_NONE) {
			add_cmnd_nio(cmnd, end_rx_ddigest);
			add_cmnd_nio(cmnd, rx_ddigest);
			add_cmnd_nio(cmnd, init_rx_ddigest);
		}
		add_cmnd_nio(cmnd, rx_data);
	}

	return 1;
}

int end_rx_hdigest(struct iscsi_cmnd *cmnd)
{
	int res;

	res = digest_rx_header(cmnd);

	return !res ? 1 : res;
}

int rx_hdigest(struct iscsi_cmnd *cmnd)
{
	int res;

	res = do_recv(cmnd);

	if (is_retry(res) && cmnd->conn->read_size)
		add_cmnd_nio(cmnd, rx_hdigest);

	return res;
}

int init_rx_hdigest(struct iscsi_cmnd *cmnd)
{
	if (cmnd->conn->hdigest_type != DIGEST_NONE) {
		iscsi_conn_init_read(cmnd->conn, &cmnd->hdigest, sizeof(u32));
		add_cmnd_nio(cmnd, end_rx_hdigest);
		add_cmnd_nio(cmnd, rx_hdigest);
	}

	return 1;
}

int rx_ahs(struct iscsi_cmnd *cmnd)
{
	int res;

	res = do_recv(cmnd);

	if (is_retry(res) && cmnd->conn->read_size)
		add_cmnd_nio(cmnd, rx_ahs);

	return res;
}

int init_rx_ahs(struct iscsi_cmnd *cmnd)
{
	iscsi_cmnd_get_length(&cmnd->pdu);

	if (cmnd->pdu.ahssize) {
		iscsi_conn_read_ahs(cmnd->conn, cmnd);
		add_cmnd_nio(cmnd, rx_ahs);
	}

	return 1;
}

int rx_bhs(struct iscsi_cmnd *cmnd)
{
	int res;

	res = do_recv(cmnd);

	if (is_retry(res) && cmnd->conn->read_size)
		add_cmnd_nio(cmnd, rx_bhs);

	return res;
}

int init_rx_bhs(struct iscsi_cmnd *cmnd)
{
	cmnd->state = ISCSI_STATE_READ;
	iscsi_conn_init_read(cmnd->conn, &cmnd->pdu.bhs, sizeof(cmnd->pdu.bhs));
	add_cmnd_nio(cmnd, rx_bhs);

	return 1;
}

static struct iscsi_cmnd *create_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;

	cmnd = iscsi_cmnd_create(conn);

	add_cmnd_nio(cmnd, init_rx_data);
	add_cmnd_nio(cmnd, init_rx_hdigest);
	add_cmnd_nio(cmnd, init_rx_ahs);
	add_cmnd_nio(cmnd, init_rx_bhs);

	return cmnd;
}

static int recv(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;
	int res = 0;

	if ((cmnd = conn->read_cmnd) == NULL)
		cmnd = conn->read_cmnd = create_cmnd(conn);

	assert(cmnd->nio_idx);
	while (cmnd->nio_idx) {
		if ((res = exec_cmnd_nio(cmnd)) <= 0)
			break;
	}

	if (res < 0)
		return res;
	if (!res)
		return -EIO;

	if (cmnd->nio_idx)
		return 0;

	if (conn->read_size) {
		eprintk("%d\n", res);
		assert(!conn->read_size);
	}

	iscsi_cmnd_finish_read(cmnd);
	if (conn->read_size) {
		add_cmnd_nio(cmnd, rx_data);
		return 1;
	}

	conn->read_cmnd = NULL;

	return is_data_available(conn) > 0 ? 1 : 0;
}

int tx_ddigest(struct iscsi_cmnd *cmnd)
{
	int res, rest = cmnd->conn->write_size;
	struct msghdr msg = {.msg_flags = MSG_NOSIGNAL | MSG_DONTWAIT};
	struct kvec iov;

	iov.iov_base = (char *) (&cmnd->ddigest) + (sizeof(u32) - rest);
	iov.iov_len = rest;

	res = kernel_sendmsg(cmnd->conn->sock, &msg, &iov, 1, rest);
	if (res > 0)
		cmnd->conn->write_size -= res;

	if (is_retry(res) && cmnd->conn->write_size)
		add_cmnd_nio(cmnd, tx_ddigest);

	return res;
}

int init_tx_ddigest(struct iscsi_cmnd *cmnd)
{
	if (cmnd->conn->ddigest_type == DIGEST_NONE)
		return 1;

	if (!cmnd->pdu.datasize)
		return 1;

	digest_tx_data(cmnd);
	assert(!cmnd->conn->write_size);
	cmnd->conn->write_size += sizeof(u32);
	add_cmnd_nio(cmnd, tx_ddigest);

	return 1;
}

int init_tx_hdigest(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	struct iovec *iop;

	if (conn->hdigest_type == DIGEST_NONE)
		return 1;

	digest_tx_header(cmnd);

	for (iop = conn->write_iop; iop->iov_len; iop++)
		;
	iop->iov_base = &(cmnd->hdigest);
	iop->iov_len = sizeof(u32);
	conn->write_size += sizeof(u32);
	iop++;
	iop->iov_len = 0;

	return 1;
}

int tx_data(struct iscsi_cmnd *cmnd)
{
	int res;

	res = iscsi_conn_write_data(cmnd->conn);

	if (is_retry(res) && cmnd->conn->write_size) {
		add_cmnd_nio(cmnd, tx_data);
		res = -EAGAIN;
	}

	return res;
}

int init_tx(struct iscsi_cmnd *cmnd)
{
	iscsi_cmnd_start_write(cmnd);
	return 1;
}

struct iscsi_cmnd * get_ready_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;

	if ((cmnd = iscsi_get_send_cmnd(conn)) == NULL)
		return NULL;

	assert(!cmnd->nio_idx);

	add_cmnd_nio(cmnd, init_tx_ddigest);
	add_cmnd_nio(cmnd, tx_data);
	add_cmnd_nio(cmnd, init_tx_hdigest);
	add_cmnd_nio(cmnd, init_tx);

	return cmnd;
}

static int send(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;
	int res = 0;

	if ((cmnd = conn->write_cmnd) == NULL)
		cmnd = conn->write_cmnd = get_ready_cmnd(conn);
	if (!cmnd)
		return 0;

	assert(cmnd->nio_idx);
	while (cmnd->nio_idx) {
		if ((res = exec_cmnd_nio(cmnd)) <= 0)
			break;
	}

	if (res < 0)
		return res;
	if (!res)
		return -EIO;

	if (cmnd->nio_idx)
		return 1;

	if (conn->write_size) {
		eprintk("%d %u\n", res, conn->write_size);
		assert(!conn->write_size);
	}
	iscsi_cmnd_finish_write(cmnd);
	iscsi_cmnd_release(cmnd);
	conn->write_cmnd = NULL;

	return list_empty(&conn->write_list) ? 0 : 1;
}

static void set_data_ready(struct iscsi_target *target)
{
	wake_up_nthread(target);
}

static void process_io(struct iscsi_conn *conn)
{
	struct iscsi_target *target = conn->session->target;
	int res, max_nr_cmnd = 8;

	do {
		res = recv(conn);
		if (res < 0)
			break;
	} while (res > 0 && max_nr_cmnd-- > 0);

	if (res < 0) {
		switch (res) {
		case -EAGAIN:
			break;
		case -EINTR:
			set_data_ready(target);
			break;
		default:
			iet_conn_close(conn);
			break;
		}
	}

	if (res > 0 || is_data_available(conn) > 0)
		set_data_ready(target);

	if (!test_bit(CONN_ACTIVE, &conn->state))
		return;

	do {
		res = send(conn);
		dprintk(D_IOD,"%u %d\n", conn->cid, res);
		if (res < 0)
			break;
	} while (res > 0);

	if (res < 0) {
		switch (res) {
		case -EAGAIN:
			set_data_ready(target);
			break;
		case -EINTR:
			set_data_ready(target);
			break;
		default:
			eprintk("%u %d\n", conn->cid, res);
			iet_conn_close(conn);
			break;
		}
	}

	if (!list_empty(&conn->write_list) || conn->write_cmnd)
			set_data_ready(target);

	return;
}

static void cleanup_write_list(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;
	LIST_HEAD(d_list);

	spin_lock(&conn->list_lock);

	if (list_empty(&conn->write_list)) {
		spin_unlock(&conn->list_lock);
		return;
	}

	list_splice_init(&conn->write_list, &d_list);
	assert(list_empty(&conn->write_list));

	spin_unlock(&conn->list_lock);

	list_for_each_entry_safe(cmnd, tmp, &d_list, list) {
		list_del_init(&cmnd->list);
		eprintk("%p,%d,%x\n", cmnd, cmnd->state, cmnd_opcode(cmnd));
		iscsi_cmnd_release(cmnd);
	}
}

static void purge_write_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;

	list_for_each_entry_safe(cmnd, tmp, &conn->pdu_list, conn_list) {
		eprintk("%p,%d,%x %x\n", cmnd, cmnd->state, cmnd_opcode(cmnd),
			cmnd->pdu.bhs.itt);

		assert(cmnd_opcode(cmnd) == ISCSI_OP_SCSI_CMD);

		list_del_init(&cmnd->list);
		target_free_pages(cmnd->data);
		iscsi_session_remove_cmnd(cmnd);
	}
}

static void cleanup_pending_list(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;

	list_for_each_entry_safe(cmnd, tmp, &conn->session->pending_list, list) {
		if (cmnd->conn != conn)
			continue;

		list_del_init(&cmnd->list);
		eprintk("%x\n", cmnd_opcode(cmnd));
		switch (cmnd_opcode(cmnd)) {
		case ISCSI_OP_NOOP_OUT:
			target_free_pages(cmnd->data);
			remove_from_itt_hashtable(cmnd);
			break;
		case ISCSI_OP_SCSI_CMD:
			target_free_pages(cmnd->data);
			remove_from_itt_hashtable(cmnd);
			break;
		case ISCSI_OP_TEXT_CMD:
			remove_from_itt_hashtable(cmnd);
			break;
		case ISCSI_OP_LOGOUT_CMD:
			remove_from_itt_hashtable(cmnd);
			break;
		default:
			eprintk("%x\n", cmnd_opcode(cmnd));
			BUG();
		}

		iscsi_cmnd_remove(cmnd);
	}
}

static void revoke_cmnd(struct iscsi_cmnd *cmnd)
{
	eprintk("%x %x\n", cmnd_opcode(cmnd), cmnd_itt(cmnd));
	switch (cmnd_opcode(cmnd)) {
	case ISCSI_OP_NOOP_OUT:
		target_free_pages(cmnd->data);
		remove_from_itt_hashtable(cmnd);
		break;
	case ISCSI_OP_SCSI_CMD:
		target_free_pages(cmnd->data);
		remove_from_itt_hashtable(cmnd);
		break;
	case ISCSI_OP_SCSI_TASK_MGT_MSG:
		remove_from_itt_hashtable(cmnd);
		break;
	case ISCSI_OP_LOGIN_CMD:
		BUG();
		break;
	case ISCSI_OP_TEXT_CMD:
		remove_from_itt_hashtable(cmnd);
		break;
	case ISCSI_OP_SCSI_DATA_OUT:
		break;
	case ISCSI_OP_LOGOUT_CMD:
		remove_from_itt_hashtable(cmnd);
		break;
	case ISCSI_OP_SNACK_CMD:
		break;
	case ISCSI_OP_PDU_REJECT:
		assert(iscsi_cmnd_get_rsp_cmnd(cmnd));
		iscsi_session_remove_cmnd(iscsi_cmnd_get_rsp_cmnd(cmnd));
		break;
	default:
		BUG();
	}
}

static void close_conn(struct iscsi_conn *conn)
{
	struct iscsi_session *session = conn->session;

	assert(conn);

	conn->sock->ops->shutdown(conn->sock, 2);

	if (conn->read_cmnd) {
		eprintk("%x %x\n", cmnd_opcode(conn->read_cmnd),
			cmnd_itt(conn->read_cmnd));
		if (conn->read_cmnd->state < ISCSI_STATE_START)
			;
		else
			revoke_cmnd(conn->read_cmnd);

		list_del_init(&conn->read_cmnd->list);
		iscsi_cmnd_remove(conn->read_cmnd);
		conn->read_cmnd = NULL;
	}

	if (conn->write_cmnd) {
		eprintk("%x %x\n", cmnd_opcode(conn->write_cmnd), cmnd_itt(conn->write_cmnd));
		iscsi_cmnd_finish_write(conn->write_cmnd);
		iscsi_cmnd_release(conn->write_cmnd);
		conn->write_cmnd = NULL;
	}

	write_lock(&conn->sock->sk->sk_callback_lock);
	conn->sock->sk->sk_state_change = session->target->nthread_info.old_state_change;
	conn->sock->sk->sk_data_ready = session->target->nthread_info.old_data_ready;
	write_unlock(&conn->sock->sk->sk_callback_lock);

	fput(conn->file);
	conn->file = NULL;
	conn->sock = NULL;

	cleanup_pending_list(conn);

	eprintk("%u\n", atomic_read(&conn->nr_busy_cmnds));
	while (atomic_read(&conn->nr_busy_cmnds))
		yield(); /* FIXME */

	cleanup_write_list(conn);
	purge_write_cmnd(conn);

	if (atomic_read(&conn->nr_cmnds) != 0) {
		struct iscsi_cmnd *cmnd;
		eprintk("%u\n", atomic_read(&conn->nr_cmnds));

		list_for_each_entry(cmnd, &conn->pdu_list, conn_list)
			eprintk("%x %x\n", cmnd_opcode(cmnd), cmnd_itt(cmnd));

		BUG();
	}

	iet_event_put(conn->session->target->tid, conn->session->sid, conn->cid,
		      E_CONN_CLOSE, 0);
	iet_conn_free(conn);

	wake_up_interruptible(&event_wait);

	if (list_empty(&session->conn_list))
		iet_session_free(session);
}

static int istd(void *arg)
{
	struct iscsi_target *target = arg;
	struct network_thread_info *info = &target->nthread_info;
	struct iscsi_conn *conn, *tmp;

	__set_current_state(TASK_RUNNING);
	do {
		clear_bit(D_DATA_READY, &info->flags);

		iet_target_lock(target, 0);
		list_for_each_entry_safe(conn, tmp, &info->active_conns, poll_list) {
			if (test_bit(CONN_ACTIVE, &conn->state))
				process_io(conn);
			else
				close_conn(conn);
		}
		iet_target_unlock(target);

		spin_lock_bh(&info->nthread_lock);
		__set_current_state(TASK_INTERRUPTIBLE);

		if (!test_bit(D_DATA_READY, &info->flags)) {
			spin_unlock_bh(&info->nthread_lock);
			schedule();
			spin_lock_bh(&info->nthread_lock);
		}
		__set_current_state(TASK_RUNNING);
		spin_unlock_bh(&info->nthread_lock);
	} while (!kthread_should_stop());

	return 0;
}

int network_thread_init(struct iscsi_target *target)
{
	struct network_thread_info *info = &target->nthread_info;

	info->flags = 0;
	info->task = NULL;

	info->old_state_change = NULL;
	info->old_data_ready = NULL;

	INIT_LIST_HEAD(&info->active_conns);

	spin_lock_init(&info->nthread_lock);

	return 0;
}

int network_thread_start(struct iscsi_target *target)
{
	int err = 0;
	struct network_thread_info *info = &target->nthread_info;
	struct task_struct *task;

	if (info->task) {
		eprintk("Target (%u) already runs\n", target->tid);
		return -EALREADY;
	}

	task = kthread_run(istd, target, "istd%d", target->tid);

	if (IS_ERR(task))
		err = PTR_ERR(task);
	else
		info->task = task;

	return err;
}

int network_thread_stop(struct iscsi_target *target)
{
	int err;
	struct network_thread_info *info = &target->nthread_info;

	if (!info->task)
		return -ESRCH;

	err = kthread_stop(info->task);

	if (!err)
		info->task = NULL;

	return err;
}
