/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/stat.h>
#include <errno.h>

#include "iscsid.h"

#define _SET_PARAM(x) info.x = conn->param.x

static int set_param(struct connection *conn)
{
	int res;
	struct target *target = conn->target;
	struct param_info info;

	info.tid = target->id;
	info.sid = conn->session->sid.id64;
	info.is_target_param = 0;

	_SET_PARAM(flags);
	_SET_PARAM(max_connections);
	_SET_PARAM(max_data_pdu_length);
	_SET_PARAM(max_burst_length);
	_SET_PARAM(first_burst_length);
	_SET_PARAM(default_wait_time);
	_SET_PARAM(default_retain_time);
	_SET_PARAM(max_outstanding_r2t);
	_SET_PARAM(error_recovery_level);

	res = ioctl(ctrl_fd, ISCSI_PARAM_SET, &info);
	if (res < 0)
		fprintf(stderr, "Can't set session param %d %d\n", info.tid, errno);
	return res;
}

struct session *session_alloc(struct target *target)
{
	struct session *session;

	session = xmalloc(sizeof(*session));
	memset(session, 0, sizeof(*session));
	session->target = target;
	if (target) {
		session->next = target->sessions;
		target->sessions = session;
	}

	return session;
}

struct session *session_find_name(struct target *target, const char *iname, union iscsi_sid sid)
{
	struct session *session;

	log_debug(1, "session_find_name: %s,%#Lx", iname, (unsigned long long) sid.id64);
	for (session = target->sessions; session; session = session->next) {
		if (!memcmp(sid.id.isid, session->sid.id.isid, 6) &&
		    !strcmp(iname, session->initiator))
			break;
	}
	return session;
}

struct session *session_find_id(struct target *target, u64 sid)
{
	struct session *session;

	log_debug(1, "session_find_id: %#Lx", (unsigned long long) sid);
	for (session = target->sessions; session; session = session->next) {
		if (session->sid.id64 == sid)
			break;
	}
	return session;
}

void session_create(struct connection *conn)
{
	struct session_info info;
	struct session *session = session_alloc(conn->target);
	static u16 tsih = 1;

	session->sid = conn->sid;
	session->sid.id.tsih = tsih;
	while (1) {
		info.tid = conn->target->id;
		info.sid = session->sid.id64;
		ioctl(ctrl_fd, GET_SESSION_INFO, &info);
		if (errno == ENOENT)
			break;
		session->sid.id.tsih++;
	}
	tsih = session->sid.id.tsih + 1;

	conn->session = session;
	conn->session->initiator = strdup(conn->initiator);

	log_debug(1, "session_create: %#Lx", (unsigned long long) session->sid.id64);
	info.tid = conn->target->id;
	info.sid = session->sid.id64;
	info.exp_cmd_sn = conn->exp_cmd_sn;
	info.max_cmd_sn = conn->max_cmd_sn;
	memcpy(info.initiator_name, conn->session->initiator, sizeof(info.initiator_name));

	ioctl(ctrl_fd, ADD_SESSION, &info);
	set_param(conn);
}

void session_remove(struct session *session)
{
	struct session_info info;

	log_debug(1, "session_remove: %#Lx", (unsigned long long) session->sid.id64);

	info.tid = session->target->id;
	info.sid = session->sid.id64;

	if (!session->sid.id.tsih)
		ioctl(ctrl_fd, DEL_SESSION, &info);

	if (session->target) {
		struct session **sp;

		for (sp = &session->target->sessions; *sp; sp = &(*sp)->next) {
			if (*sp == session)
				break;
		}
		if (*sp) {
			session->target->session_cnt--;
			*sp = session->next;
		} else
			log_warning("session_remove: session %#Lx not found?",
				    (unsigned long long) session->sid.id64);
	}

	free(session->initiator);
	free(session);
}
