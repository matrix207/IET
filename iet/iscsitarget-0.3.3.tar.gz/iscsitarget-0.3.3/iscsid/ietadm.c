/*
 * ietadm - manage iSCSI Enterprise Target software.
 *
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

/* This code is makeshift. It should be rewritten. */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "iscsid.h"
#include "iet_u.h"

#define CTL_DEVICE "/dev/ietctl"
#define SESSION "/proc/net/iet/session"

enum ietadm_mode {
	MODE_ADD,
	MODE_DEL,
	MODE_STOP,
};

enum iet_ops {
	OPS_CONN_CLOSE,
	OPS_SHUTDOWN_WAIT,
	OPS_TARGET_DEL,
};

static struct option const long_options[] =
{
	{"mode", required_argument, 0, 'm'},
	{"tid", required_argument, 0, 't'},
	{"sid", required_argument, 0, 's'},
	{"cid", required_argument, 0, 'c'},
	{"lun", required_argument, 0, 'l'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void target_delete(int fd, u32 tid)
{
	struct target_info info;

	info.tid = tid;
	if (ioctl(fd, DEL_TARGET, &info) < 0)
		perror("DEL_TARGET");
}

static void conn_close(int fd, u32 tid, u64 sid, u32 cid)
{
	struct conn_info info;

	info.tid = tid;
	info.sid = sid;
	info.cid = cid;

	if (ioctl(fd, DEL_CONN, &info) < 0)
		perror("DEL_CONN");
}

static int __server_stop(int fd, int ops)
{
	FILE *f;
	char buf[8192], *p;
	u32 tid, cid;
	u64 sid;

	f = fopen(SESSION, "r");
	if (!f) {
		fprintf(stderr, "Can't open %s\n", SESSION);
		exit(-1);
	}

	while (fgets(buf, sizeof(buf), f)) {
		p = buf;
		while (isspace((int) *p))
			p++;

		if (!strncmp(p, "tid:", 4)) {
			if (sscanf(p, "tid:%u", &tid) != 1)
				break;
			if (ops == OPS_TARGET_DEL)
				target_delete(fd, tid);

		} else if (!strncmp(p, "sid:", 4)) {
			if (sscanf(p, "sid:%llu", &sid) != 1)
				break;
			if (ops == OPS_SHUTDOWN_WAIT) {
				fclose(f);
				return -EAGAIN;
			} else if (ops == OPS_TARGET_DEL)
				printf("%s %d: BUG\n", __FUNCTION__, __LINE__);

		} else if (!strncmp(p, "cid:", 4)) {
			if (sscanf(p, "cid:%u", &cid) != 1)
				break;

			if (ops == OPS_CONN_CLOSE)
				conn_close(fd, tid, sid, cid);
			else if (ops == OPS_SHUTDOWN_WAIT) {
				fclose(f);
				return -EAGAIN;
			} else if (ops == OPS_TARGET_DEL)
				printf("%s %d: BUG\n", __FUNCTION__, __LINE__);
		}
	}

	fclose(f);

	return 0;
}

static void server_stop(int fd)
{
	int count = 0;
	__server_stop(fd, OPS_CONN_CLOSE);

	while (__server_stop(fd, OPS_SHUTDOWN_WAIT) < 0) {
		printf("%s %d: retry %d\n", __FUNCTION__, __LINE__, count);
		sleep(1);
	}

	__server_stop(fd, OPS_TARGET_DEL);
}

static int open_ctrdev(void)
{
	FILE *f = NULL;
	char devname[256];
	char buf[256];
	int devn;
	int ctlfd;

	f = fopen("/proc/devices", "r");
	if (!f) {
		perror("Cannot open control path to the driver");
		return -1;
	}

	devn = 0;
	while (!feof(f)) {
		if (!fgets(buf, sizeof (buf), f)) {
			break;
		}
		if (sscanf(buf, "%d %s", &devn, devname) != 2) {
			continue;
		}
		if (!strcmp(devname, "ietctl")) {
			break;
		}
		devn = 0;
	}

	fclose(f);
	if (!devn) {
		printf
		    ("cannot find iscsictl in /proc/devices - make "
		     "sure the module is loaded");
		return -1;
	}

	unlink(CTL_DEVICE);
	if (mknod(CTL_DEVICE, (S_IFCHR | 0600), (devn << 8))) {
		printf("cannot create %s ", CTL_DEVICE);
		return -1;
	}

	ctlfd = open(CTL_DEVICE, O_RDWR);
	if (ctlfd < 0) {
		printf("cannot open %s", CTL_DEVICE);
		return -1;
	}

	return ctlfd;
}

static int str_to_mode(char *str)
{
	int mode;

	if (!strcmp("add", str))
		mode = MODE_ADD;
	else if (!strcmp("del", str))
		mode = MODE_DEL;
	else
		mode = -1;

	return mode;
}

int handle_volume(int fd, int mode, u32 tid, u32 vid, char *path)
{
	struct volume_info info;
	char iomode[] = "fileio";
	struct stat s;

	if (stat(path, &s))
		return -1;

	memset(&info, 0, sizeof(info));

	info.tid = tid;
	info.lun = vid;
	info.major = major(s.st_rdev);
	info.minor = minor(s.st_rdev);

	memcpy(info.path, path, sizeof(info.path) - 1);
	memcpy(info.mode, iomode, sizeof(info.mode) - 1);

	return ioctl(fd, ADD_VOLUME, &info);
}

int main(int argc, char **argv)
{
	int fd, ch, longindex, mode = -1;
	u32 id[4], tid = 0, cid = 0, vid = 0;
	u64 sid = 0;

	memset(id, 0, sizeof(id));

	while ((ch = getopt_long(argc, argv, "m:t:s:c:l:h", long_options, &longindex)) >= 0) {
		switch (ch) {
		case 'm':
			mode = str_to_mode(optarg);
			break;
		case 't':
			tid = strtoul(optarg, NULL, 10);
			id[0]++;
			break;
		case 's':
			sid = strtoull(optarg, NULL, 10);
			id[1]++;
			break;
		case 'c':
			cid = strtoul(optarg, NULL, 10);
			id[2]++;
			break;
		case 'l':
			vid = strtoul(optarg, NULL, 10);
			id[3]++;
			break;
		}
	}

	fd = open_ctrdev();
	if (fd < 0) {
		fprintf(stderr, "Can't open dev\n");
		exit(-1);
	}

	if (mode < 0) {
		fprintf(stderr, "You must specify the mode\n");
		exit(-1);
	}

	if (mode == MODE_DEL && !strcmp("all", argv[optind])) {
		printf("stop server\n");
		server_stop(fd);
		return 0;
	}

	if (id[3]) {
		if (!id[0]) {
			fprintf(stderr, "You must specify tid\n");
			exit(-1);
		}
		handle_volume(fd, mode, tid, vid, argv[optind]);

	} else if (id[2]) {
		if (mode == MODE_ADD) {
			fprintf(stderr, "Unsupported\n");
			exit(-1);
		}

		if (!id[0] || !id[1]) {
			fprintf(stderr, "You must specify tid and sid\n");
			exit(-1);
		}

		conn_close(fd, tid, sid, cid);

	} else if (id[0]) {
		if (mode == MODE_ADD) {
			fprintf(stderr, "Not implemented\n");
			exit(-1);
		} else {
			target_delete(fd, tid);
		}
	} else
		fprintf(stderr, "something wrong\n");

	return 0;
}
