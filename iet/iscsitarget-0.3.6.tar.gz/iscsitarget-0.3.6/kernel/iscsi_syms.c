/*
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/config.h>
#include <linux/module.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "iotype.h"

EXPORT_SYMBOL(register_iotype);
EXPORT_SYMBOL(unregister_iotype);

EXPORT_SYMBOL(debug_enable_flags);
