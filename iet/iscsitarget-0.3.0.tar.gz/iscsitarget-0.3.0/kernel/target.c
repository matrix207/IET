/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

static LIST_HEAD(target_list);
static DECLARE_MUTEX(target_list_sem);

int iet_is_target_running(struct iscsi_target *target)
{
	return test_bit(T_RUNNING, &target->state);
}

inline int iet_target_lock(struct iscsi_target *target, int interruptible)
{
	int res = 0;

	if (interruptible)
		res = down_interruptible(&target->target_sem);
	else
		down(&target->target_sem);

	return res;
}

inline void iet_target_unlock(struct iscsi_target *target)
{
	up(&target->target_sem);
}

struct iscsi_target *__iet_target_lookup(u32 id)
{
	struct iscsi_target *target;

	list_for_each_entry(target, &target_list, target.list) {
		if (target->target.id == id)
			return target;
	}
	return NULL;
}

struct iscsi_target *iet_target_lookup(u32 id)
{
	struct iscsi_target *target;

	down(&target_list_sem);
	target = __iet_target_lookup(id);
	up(&target_list_sem);

	return target;
}

#define MAX_NR_WTHREADS 128

static void iet_target_param_check(struct param_info *info)
{
	if (info->max_connections != 1)
		eprintk("The max_connections (%u) should be 1\n", info->max_connections);

	if (info->max_data_pdu_length < PAGE_SIZE) {
		eprintk("max_data_pdu_length (%u) > PAGE_SIZE\n", info->max_data_pdu_length);
		info->max_data_pdu_length = PAGE_SIZE;
	}

	if (info->max_burst_length < PAGE_SIZE) {
		eprintk("max_burst_length (%u) > PAGE_SIZE\n", info->max_burst_length);
		info->max_burst_length = PAGE_SIZE;
	}

	if (info->first_burst_length < PAGE_SIZE) {
		eprintk("max_burst_length (%u) > PAGE_SIZE\n", info->first_burst_length);
		info->first_burst_length = PAGE_SIZE;
	}

	if (info->max_outstanding_r2t != 1)
		eprintk("max_outstanding_r2t (%u) should be 1\n", info->max_outstanding_r2t);

	if (info->error_recovery_level != 0) {
		eprintk("error_recovery_level (%u) must be 0\n", info->error_recovery_level);
		info->error_recovery_level = 0;
	}

	if (info->nr_wthreads < 1 || info->nr_wthreads > MAX_NR_WTHREADS) {
		eprintk("0 < nr_wthreads (%u) < %u\n", info->nr_wthreads, MAX_NR_WTHREADS);
		info->nr_wthreads = 1;
	}
}

#define __SET_PARAM(x) target->default_param.x = info->x

int iet_target_param_set(struct iscsi_target *target, struct param_info *info)
{
	if (test_bit(T_RUNNING, &target->state)) {
		eprintk("Can't change params of a running target %u\n", target->target.id);
		return -EALREADY;
	}

	iet_target_param_check(info);

	__SET_PARAM(flags);
	__SET_PARAM(max_connections);
	__SET_PARAM(max_data_pdu_length);
	__SET_PARAM(max_burst_length);
	__SET_PARAM(first_burst_length);
	__SET_PARAM(default_wait_time);
	__SET_PARAM(default_retain_time);
	__SET_PARAM(max_outstanding_r2t);
	__SET_PARAM(error_recovery_level);

	target->nr_wthreads = info->nr_wthreads;

	return 0;
}

static int iet_target_alloc(struct target_info *info)
{
	int res = -ENOMEM;
	u32 id = info->tid;
	char *name = info->name;
	struct iscsi_target *target;

	if (strlen(name) <= 0)
		return -EINVAL;

	dprintk(D_SETUP, "%u %s\n", id, name);
	target = kmalloc(sizeof(*target), GFP_KERNEL);
	if (!target)
		return res;
	memset(target, 0, sizeof(*target));

	target->target.id = id;
	memcpy(&target->default_param, &default_iscsi_param, sizeof(default_iscsi_param));

	target->name = kmalloc(strlen(name) + 1, GFP_KERNEL);
	if (!target->name)
		goto out;
	strcpy(target->name, name);

	target->nr_wthreads = 8;

	init_MUTEX(&target->target_sem);

	INIT_LIST_HEAD(&target->session_list);
	INIT_LIST_HEAD(&target->volumes);

	atomic_set(&target->nr_volumes, 0);

	list_add(&target->target.list, &target_list);

	MOD_INC_USE_COUNT;

	return 0;
out:
	kfree(target);
	return res;
}

int iet_target_add(struct target_info *info)
{
	struct iscsi_target *target;
	int res = -EEXIST;

	down(&target_list_sem);
	target = __iet_target_lookup(info->tid);

	if (target)
		goto out;

	res = iet_target_alloc(info);
out:
	up(&target_list_sem);
	return res;
}

static int iet_target_free(struct iscsi_target *target)
{
	dprintk(D_SETUP, "%u\n", target->target.id);

	if (!list_empty(&target->session_list))
		return -EBUSY;

	while (sem_getcount(&target->target_sem) != 1)
		schedule();

	eprintk("Ready to remove target (%u)\n", target->target.id);

	list_del(&target->target.list);

	if (test_bit(T_RUNNING, &target->state)) {
		stop_worker_threads(target);
		stop_target_thread(target);
	}

	while (!list_empty(&target->volumes)) {
		struct iet_volume *volume;
		volume = list_entry(target->volumes.next, struct iet_volume, list);
		iet_volume_del(volume);
	}

	kfree(target->name);
/* 	kfree(target->alias); */
	kfree(target);

	MOD_DEC_USE_COUNT;

	return 0;
}

int iet_target_del(u32 id)
{
	struct iscsi_target *target;
	int res;

	if ((res = down_interruptible(&target_list_sem)) < 0)
		return res;

	target = __iet_target_lookup(id);
	if (!target) {
		res = -ENOENT;
		goto out;
	}

	res = iet_target_free(target);

out:
	up(&target_list_sem);

	return res;
}

int iet_target_start(struct iscsi_target *target)
{
	if (test_and_set_bit(T_RUNNING, &target->state)) {
		eprintk("Target (%u) already runs\n", target->target.id);
		return -EALREADY;
	}

	start_target_thread(target);
	start_worker_threads(target);

	return 0;
}

int iet_info_show(struct seq_file *seq, iet_show_info_t *func)
{
	int res;
	struct iscsi_target *target;

	if ((res = down_interruptible(&target_list_sem)) < 0)
		return res;

	list_for_each_entry(target, &target_list, target.list) {
		seq_printf(seq, "tid:%u name:%s\n", target->target.id, target->name);

		if ((res = iet_target_lock(target, 1)) < 0)
			break;

		func(seq, target);

		iet_target_unlock(target);
	}

	up(&target_list_sem);

	return 0;
}
