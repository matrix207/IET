/*
 * ietadm - manage iSCSI Enterprise Target software.
 *
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

/* This code is makeshift. It should be rewritten. */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "iscsid.h"
#include "iet_u.h"

#define CTL_DEVICE "/dev/ietctl"
#define SESSION "/proc/net/iet/session"

enum ietadm_mode {
	MODE_ADD,
	MODE_DEL,
	MODE_STOP,
};

static struct option const long_options[] =
{
	{"mode", required_argument, 0, 'm'},
	{"tid", required_argument, 0, 't'},
	{"sid", required_argument, 0, 's'},
	{"cid", required_argument, 0, 'c'},
	{"lun", required_argument, 0, 'l'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void server_stop(int fd)
{
	FILE *f;
	char buf[8192], *p;
	u32 tid, cid;
	u64 sid;
	int count = 0;
	struct target_info info;

	f = fopen(SESSION, "r");
	if (!f) {
		fprintf(stderr, "Can't open %s\n", SESSION);
		exit(-1);
	}

	while (fgets(buf, sizeof(buf), f)) {
		p = buf;
		while (isspace((int) *p))
			p++;

		if (!strncmp(p, "tid:", 4)) {
			if (count) {
				info.tid = tid;
				if (ioctl(fd, DEL_TARGET, &info) < 0)
					perror("DEL_TARGET");
			}
			if (sscanf(p, "tid:%u", &tid) != 1)
				break;
			count++;
		} else if (!strncmp(p, "sid:", 4)) {
			if (sscanf(p, "sid:%llu", &sid) != 1)
				break;
		} else if (!strncmp(p, "cid:", 4)) {
			struct conn_info info;
			if (sscanf(p, "cid:%u", &cid) != 1)
				break;

			info.tid = tid;
			info.sid = sid;
			info.cid = cid;

			if (ioctl(fd, DEL_CONN, &info) < 0)
				perror("DEL_CONN");
		}
	}

	if (count) {
		info.tid = tid;
		if (ioctl(fd, DEL_TARGET, &info) < 0)
			perror("DEL_TARGET");
	}

	fclose(f);
}

static int open_ctrdev(void)
{
	FILE *f = NULL;
	char devname[256];
	char buf[256];
	int devn;
	int ctlfd;

	f = fopen("/proc/devices", "r");
	if (!f) {
		perror("Cannot open control path to the driver");
		return -1;
	}

	devn = 0;
	while (!feof(f)) {
		if (!fgets(buf, sizeof (buf), f)) {
			break;
		}
		if (sscanf(buf, "%d %s", &devn, devname) != 2) {
			continue;
		}
		if (!strcmp(devname, "ietctl")) {
			break;
		}
		devn = 0;
	}

	fclose(f);
	if (!devn) {
		printf
		    ("cannot find iscsictl in /proc/devices - make "
		     "sure the module is loaded");
		return -1;
	}

	unlink(CTL_DEVICE);
	if (mknod(CTL_DEVICE, (S_IFCHR | 0600), (devn << 8))) {
		printf("cannot create %s ", CTL_DEVICE);
		return -1;
	}

	ctlfd = open(CTL_DEVICE, O_RDWR);
	if (ctlfd < 0) {
		printf("cannot open %s", CTL_DEVICE);
		return -1;
	}

	return ctlfd;
}

static int str_to_mode(char *str)
{
	int mode;

	if (!strcmp("add", str))
		mode = MODE_ADD;
	else if (!strcmp("del", str))
		mode = MODE_DEL;
	else
		mode = -1;

	return mode;
}

int handle_volume(int fd, int mode, u32 tid, u32 vid, char *path)
{
	struct volume_info info;
	char iomode[] = "fileio";
	struct stat s;

	if (stat(path, &s))
		return -1;

	memset(&info, 0, sizeof(info));

	info.tid = tid;
	info.lun = vid;
	info.major = major(s.st_rdev);
	info.minor = minor(s.st_rdev);

	memcpy(info.path, path, sizeof(info.path) - 1);
	memcpy(info.mode, iomode, sizeof(info.mode) - 1);

	return ioctl(fd, ADD_VOLUME, &info);
}

int main(int argc, char **argv)
{
	int fd, ch, longindex, mode = -1;
	u32 id[4], tid = 0, cid = 0, vid = 0;
	u64 sid = 0;

	memset(id, 0, sizeof(id));

	while ((ch = getopt_long(argc, argv, "m:t:s:c:l:h", long_options, &longindex)) >= 0) {
		switch (ch) {
		case 'm':
			mode = str_to_mode(optarg);
			break;
		case 't':
			tid = strtoul(optarg, NULL, 10);
			id[0]++;
			break;
		case 's':
			sid = strtoull(optarg, NULL, 10);
			id[1]++;
			break;
		case 'c':
			cid = strtoul(optarg, NULL, 10);
			id[2]++;
			break;
		case 'l':
			vid = strtoul(optarg, NULL, 10);
			id[3]++;
			break;
		}
	}

	fd = open_ctrdev();
	if (fd < 0) {
		fprintf(stderr, "Can't open dev\n");
		exit(-1);
	}

	if (mode < 0) {
		fprintf(stderr, "You must specify the mode\n");
		exit(-1);
	}

	if (mode == MODE_DEL && !strcmp("all", argv[optind])) {
		printf("stop server\n");
		server_stop(fd);
		return 0;
	}

	if (id[3]) {
		if (!id[0]) {
			fprintf(stderr, "You must specify tid\n");
			exit(-1);
		}

		return handle_volume(fd, mode, tid, vid, argv[optind]);
	}

	if (id[2]) {
		struct conn_info info;

		info.tid = tid;
		info.sid = sid;
		info.cid = cid;

		if (ioctl(fd, DEL_CONN, &info) < 0)
			perror("DEL_CONN");
	} else if (id[1]) {
		struct session_info info;

		info.tid = tid;
		info.sid = sid;

		if (ioctl(fd, DEL_SESSION, &info) < 0)
			perror("SESSION_DEL");
	} else if (id[0]) {
		struct target_info info;

		info.tid = tid;

		if (ioctl(fd, DEL_TARGET, &info) < 0)
			perror("TARGET_DEL");
	} else
		fprintf(stderr, "something wrong\n");

	return 0;
}
