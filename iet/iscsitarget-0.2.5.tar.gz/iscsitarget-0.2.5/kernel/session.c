/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

struct iscsi_session *iscsi_target_lookup_session(struct iscsi_target *target, u64 sid)
{
	struct iscsi_session *session;

	list_for_each_entry(session, &target->session_list, list) {
		if (session->sid == sid)
			return session;
	}
	return NULL;
}

static int do_iscsi_session_create(struct iscsi_target *target, u64 sid)
{
	struct iscsi_session *session;

	dprintk(D_SETUP, "%p %u %#Lx\n", target, target->target.id, sid);
	session = kmalloc(sizeof(*session), GFP_KERNEL);
	if (!session) {
		printk("%s(%d) ENOMEM\n", __FUNCTION__, __LINE__);
		return -ENOMEM;
	}
	memset(session, 0, sizeof(*session));

	session->target = target;
	session->sid = sid;
	memcpy(&session->param, &target->default_param, sizeof(session->param));

	init_MUTEX(&session->conn_list_sem);
	INIT_LIST_HEAD(&session->conn_list);
	INIT_LIST_HEAD(&session->pending_list);
	spin_lock_init(&session->cmnd_tt_lock);
	session->next_ttt = 1;

	list_add(&session->list, &target->session_list);
	iscsi_session_proc_init(session);

	return 0;
}

int iscsi_session_create(struct iscsi_target *target, u64 sid)
{
	struct iscsi_session *session;
	int res = -EEXIST;

	write_lock_target(target);
	session = iscsi_target_lookup_session(target, sid);

	if (session)
		goto out;

	res = do_iscsi_session_create(target, sid);

out:
	write_unlock_target(target);

	return res;
}

static int do_iscsi_session_remove(struct iscsi_session *session)
{
	struct iscsi_cmnd *cmnd;
	int i;

	dprintk(D_SETUP, "%#Lx\n", session->sid);

	if (!list_empty(&session->conn_list)) {
		printk("%s(%d) %#Lx still have connections\n",
		       __FUNCTION__, __LINE__, session->sid);
		up(&session->conn_list_sem);
		return -EBUSY;
	}
	// check for commands
	for (i = 0; i < ISCSI_TT_HASHSIZE; i++) {
		while ((cmnd = session->cmnd_itt_hash[i])) {
			printk("remove cmnd %p (%d)\n", cmnd, cmnd->state);
			iscsi_session_remove_cmnd(cmnd);
		}
	}

	list_del(&session->list);

	iscsi_session_proc_exit(session);

	kfree(session);

	return 0;
}

int iscsi_session_remove(struct iscsi_target *target, u64 sid)
{
	struct iscsi_session *session;
	int res = -ENOENT;

	dprintk(D_SETUP,"%llx\n", sid);
	write_lock_target(target);
	session = iscsi_target_lookup_session(target, sid);

	if (!session)
		goto out;

	res = do_iscsi_session_remove(session);

out:
	write_unlock_target(target);

	return res;
}
