/*
 * sha1.h - SHA1 Secure Hash Algorithm used for CHAP authentication.
 * copied from the Linux kernel's Cryptographic API and slightly adjusted to
 * fit IET's needs
 *
 * This file is (c) 2004 Xiranet Communications GmbH <arne.redlich@xiranet.com>
 * and licensed under the GPL.
 */

#ifndef SHA1_H
#define SHA1_H

#include <sys/types.h>
#include <string.h>
#include "types.h"

struct sha1_ctx {
        u64 count;
        u32 state[5];
        u8 buffer[64];
};

void sha1_init(void *ctx);
void sha1_update(void *ctx, const u8 *data, unsigned int len);
void sha1_final(void* ctx, u8 *out);

#endif
