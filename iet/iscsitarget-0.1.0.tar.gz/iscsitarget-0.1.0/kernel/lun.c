/*
 * Logical Unit Number
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/slab.h>
#include <linux/mm.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "target_device.h"

static int alloc_iscsi_queue(struct iscsi_lun *lun)
{
	INIT_LIST_HEAD(&lun->queue.wait_list);
	spin_lock_init(&lun->queue.queue_lock);

	return 0;
}

static void free_iscsi_queue(struct iscsi_lun *lun)
{
	assert(list_empty(&lun->queue.wait_list));
}

static struct iscsi_lun *target_lookup_lun_nolock(struct iscsi_target *target, u32 lun_id)
{
	struct iscsi_lun *lun;

	list_for_each_entry(lun, &target->lun_list, list) {
		if (lun->lun_id == lun_id)
			return lun;
	}
	return NULL;
}

struct iscsi_lun *target_lookup_lun(struct iscsi_target *target, u32 lun_id)
{
	struct iscsi_lun *lun;

	spin_lock(&target->lun_lock);
	lun = target_lookup_lun_nolock(target, lun_id);
	spin_unlock(&target->lun_lock);

	return lun;
}

int alloc_iscsi_lun(struct iscsi_target *target, struct target_device *dev, u32 lun_id,
		    int (*constructor)(struct iscsi_lun *))
{
	int res = 0;
	struct iscsi_lun *lun;

	lun = target_lookup_lun(target, lun_id);

	if (lun)
		return -EEXIST;

	lun = kmalloc(sizeof(*lun), GFP_KERNEL);
	if (!lun)
		return -ENOMEM;
	memset(lun, 0, sizeof(*lun));

	lun->target = target;
	lun->lun_id = lun_id;
	lun->device = dev;

	res = alloc_iscsi_queue(lun);
	if (res < 0) {
		kfree(lun);
		return -ENOMEM;
	}

	spin_lock(&target->lun_lock);

	if (target_lookup_lun_nolock(target, lun_id)) {
		printk("%s(%d) someone created\n", __FUNCTION__, __LINE__);
		free_iscsi_queue(lun);
		kfree(lun);
		res = -EEXIST;
		goto out;
	}

	list_add_tail(&lun->list, &target->lun_list);
	atomic_inc(&target->lun_cnt);

out:
	spin_unlock(&target->lun_lock);

	if (res == 0) {
		res = constructor(lun);
		assert(res == 0); /* FIXME */
	}

	return res;
}

int free_iscsi_lun(struct iscsi_target *target, u32 lun_id,
		   void (*destructor)(struct iscsi_lun *))
{
	int res = 0;
	struct iscsi_lun *lun;

	spin_lock(&target->lun_lock);
	lun = target_lookup_lun_nolock(target, lun_id);
	if (!lun) {
		res = -ENXIO;
	} else {
		list_del(&lun->list);
	}
	spin_unlock(&target->lun_lock);

	if (res < 0)
		return res;

	assert(lun->device);
	target_device_put(lun->device);
	atomic_dec(&target->lun_cnt);

	free_iscsi_queue(lun);
	destructor(lun);
	kfree(lun);

	return res;
}
