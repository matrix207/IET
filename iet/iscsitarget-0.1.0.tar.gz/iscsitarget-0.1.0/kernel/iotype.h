/*
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#ifndef __IOTYPE_H__
#define __IOTYPE_H__

struct iotype {
	const char *name;
	struct module *owner;
	struct list_head iot_list;

	int (*attach)(struct target_device *dev, const char *path);
	int (*make_request)(struct target_device *dev, struct target_cmnd *tcmnd, int rw);
	int (*sync)(struct target_device *dev, struct target_cmnd *tcmnd);
	void (*detach)(struct target_device *dev);
};

extern int register_iotype(struct iotype *iot);
extern int unregister_iotype(struct iotype *iot);

#endif
