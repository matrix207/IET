/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#ifndef __ISCSI_H__
#define __ISCSI_H__

#include <linux/poll.h>
#include <linux/rwsem.h>
#include <linux/seq_file.h>

#include "target.h"
#include "iscsi_hdr.h"
#include "iet_u.h"

extern wait_queue_head_t event_wait;

struct iscsi_param {
	u32 flags;
	int max_connections;
	int max_data_pdu_length;
	int max_burst_length;
	int first_burst_length;
	int default_wait_time;
	int default_retain_time;
	int max_outstanding_r2t;
	int error_recovery_level;
};

extern struct iscsi_param default_iscsi_param;

#define SESSION_FLG_INITIAL_RTT		0x0001
#define SESSION_FLG_IMMEDIATEDATA	0x0002
#define SESSION_FLG_DATAPDUINORDER	0x0004
#define SESSION_FLG_DATASEQUENCEINORDER	0x0008

struct iscsi_daemon {
	unsigned long flags;

	struct list_head active_conns;

	wait_queue_head_t wq;
};

struct worker_thread;

enum target_state_bit {
	T_RUNNING,
};

struct iscsi_target {
	struct target target;

	char *name;
	struct iscsi_param default_param;

	atomic_t nr_volumes;
	struct list_head volumes;
	struct list_head session_list;

	struct iscsi_daemon daemon;

	u32 nr_wthreads;
	struct worker_thread *wt;

	void (*old_state_change)(struct sock *);
	void (*old_data_ready)(struct sock *, int);

	struct semaphore target_sem;

	unsigned long state;
};

struct worker_thread {
	struct iscsi_target *target;

	int threads;
	int shutdown;
	spinlock_t worker_lock;
	struct list_head work_queue;

	wait_queue_head_t thread_sleep;
	wait_queue_head_t shutdown_wait;
};

struct iscsi_queue {
	spinlock_t queue_lock;
	struct iscsi_cmnd *ordered_cmnd;
	struct list_head wait_list;
	int active_cnt;
};

struct iet_volume {
	u32 lun;

	struct iscsi_target *target;
	struct list_head list;

	struct iscsi_queue queue;

	kdev_t dev;

	int blk_shift;
	int blk_cnt;

	struct iotype *iotype;
	void *private;
};

#define ISCSI_TT_HASHSHIFT	8
#define ISCSI_TT_HASHSIZE	(1<<ISCSI_TT_HASHSHIFT)
#define ISCSI_TT_HASHMASK	(ISCSI_TT_HASHSIZE-1)
#define ISCSI_TT_HASH(itt) ({					\
	u32 __hash = (itt) ^ ((itt)>>16);			\
	(__hash ^ (__hash >> 8)) & ISCSI_TT_HASHMASK;		\
})

struct iscsi_session {
	struct list_head list;
	struct iscsi_target *target;

	char *initiator;
	u64 sid;

	u32 exp_cmd_sn;
	u32 max_cmd_sn;

	struct iscsi_param param;

	struct list_head conn_list;

	struct list_head pending_list;

	spinlock_t cmnd_tt_lock;
	struct iscsi_cmnd *cmnd_itt_hash[ISCSI_TT_HASHSIZE];
	struct iscsi_cmnd *cmnd_ttt_hash[ISCSI_TT_HASHSIZE];
	u32 next_ttt;
};

enum connection_state_bit {
	CONN_NEW,
	CONN_ACTIVE,
	CONN_CLOSING,
};

#define ISCSI_CONN_IOV_MAX	32

struct iscsi_conn {
	struct list_head list;			/* list entry in session list */
	struct iscsi_session *session;		/* owning session */

	u16 cid;
	unsigned long state;

	u32 stat_sn;
	u32 exp_stat_sn;

	int header_digest;
	int data_digest;

	struct list_head poll_list;

	struct file *file;
	struct socket *sock;
	spinlock_t list_lock;
	atomic_t nr_cmnds;
	atomic_t nr_busy_cmnds;
	struct list_head pdu_list;		/* in/outcoming pdus */
	struct list_head write_list;		/* list of data pdus to be sent */

	struct iscsi_cmnd *read_cmnd;
	struct msghdr read_msg;
	struct iovec read_iov[ISCSI_CONN_IOV_MAX];
	u32 read_size;
	u32 read_overflow;
	int read_state;

	struct iscsi_cmnd *write_cmnd;
	struct iovec write_iov[ISCSI_CONN_IOV_MAX];
	struct iovec *write_iop;
	struct target_cmnd *write_tcmnd;
	u32 write_size;
	u32 write_offset;
	int write_state;
};

struct iscsi_pdu {
	struct iscsi_hdr bhs;
	void *ahs;
	unsigned int ahssize;
	unsigned int datasize;
};

struct kevent {
	struct iet_event ev;
	struct list_head list;
};

struct iscsi_cmnd;

typedef void (process_cmnd_t)(struct iscsi_cmnd *cmnd);
typedef void (iet_show_info_t)(struct seq_file *seq, struct iscsi_target *target);

struct iscsi_cmnd {
	struct list_head list;
	struct list_head conn_list;
	int state;
	struct iscsi_conn *conn;
	struct iscsi_cmnd *hash_next;
	struct iet_volume *lun;

	struct iscsi_pdu pdu;
	struct list_head pdu_list;

	void *data;

	struct iscsi_cmnd *req;
	process_cmnd_t *func;
};

#define ISCSI_OP_SCSI_REJECT	ISCSI_OP_VENDOR1_CMD
#define ISCSI_OP_PDU_REJECT	ISCSI_OP_VENDOR2_CMD
#define ISCSI_OP_DATA_REJECT	ISCSI_OP_VENDOR3_CMD
#define ISCSI_OP_SCSI_ABORT	ISCSI_OP_VENDOR4_CMD

#define ISCSI_STATE_NEW			0
#define ISCSI_STATE_READ		1
#define ISCSI_STATE_WRITE		2
#define ISCSI_STATE_WRITE_DONE		3
#define ISCSI_STATE_PUSHED		4
#define ISCSI_STATE_QUEUED		5
#define ISCSI_STATE_PENDING		6
#define ISCSI_STATE_HOQ_MARKER		7
#define ISCSI_STATE_ACTIVE		8
#define ISCSI_STATE_START_READ		9
#define ISCSI_STATE_WAIT_READ		10
#define ISCSI_STATE_SEND_DATA		11
#define ISCSI_STATE_SEND_RSP		12
#define ISCSI_STATE_SEND_R2T		13
#define ISCSI_STATE_WAIT_RECEIVE	14
#define ISCSI_STATE_WAIT_ASYNC		15
#define ISCSI_STATE_WAIT_WRITE_PAGES	16
#define ISCSI_STATE_WAIT_COMMIT		17
#define ISCSI_STATE_WAIT_WRITE		18

extern void iscsi_device_queue_cmnd(struct iscsi_cmnd *cmnd);

extern int iscsi_session_insert_cmnd(struct iscsi_cmnd *cmnd);
extern struct iscsi_cmnd *iscsi_session_find_cmnd(struct iscsi_session *session, u32 itt);
extern void iscsi_session_remove_cmnd(struct iscsi_cmnd *cmnd);
extern void iscsi_session_insert_ttt(struct iscsi_cmnd *cmnd);
extern struct iscsi_cmnd *iscsi_session_find_ttt(struct iscsi_session *session, u32 ttt);
extern void iscsi_session_remove_ttt(struct iscsi_cmnd *cmnd);
extern void iscsi_session_push_cmnd(struct iscsi_cmnd *cmnd);

/* conn.c */
extern struct iscsi_conn *iet_conn_lookup(struct iscsi_session *session, u16 cid);
extern int iet_conn_add(struct iscsi_session *session, struct conn_info *info);
extern int iet_conn_del(struct iscsi_session *session, struct conn_info *info);
extern int iet_conn_free(struct iscsi_conn *conn);
extern void iet_conn_close(struct iscsi_conn *conn);
extern int iscsi_conn_write_data(struct iscsi_conn *conn);
extern void iscsi_conn_update_stat_sn(struct iscsi_cmnd *cmnd);

extern struct iscsi_cmnd *iscsi_cmnd_create(struct iscsi_conn *conn);
extern struct iscsi_cmnd *iscsi_cmnd_create_rsp_cmnd(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_remove(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_start_read(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_finish_read(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_execute(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_init_write(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_start_write(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_finish_write(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_release(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_reject(struct iscsi_cmnd *cmnd, int reason);
extern struct iscsi_cmnd *iscsi_cmnd_scsi_rsp(struct iscsi_cmnd *scsi_cmnd);
extern struct iscsi_cmnd *iscsi_cmnd_sense_rsp(struct iscsi_cmnd *scsi_cmnd, u8 sense_key, u8 asc, u8 ascq);
extern void iscsi_cmnd_skip_pdu(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_ignore_data(struct iscsi_cmnd *scsi_cmnd);
extern void iscsi_cmnd_prepare_send(struct iscsi_cmnd *cmnd);
extern void iscsi_cmnd_send_pdu(struct iscsi_conn *conn, struct target_cmnd *tcmnd, u32 offset, u32 size);
extern void iscsi_cmnd_receive_pdu(struct iscsi_conn *conn, struct target_cmnd *tcmnd, u32 offset, u32 size);
extern void iscsi_cmnd_set_sn(struct iscsi_cmnd *cmnd, int set_stat_sn);
extern u32 iscsi_cmnd_write_size(struct iscsi_cmnd *cmnd);
extern u32 iscsi_cmnd_read_size(struct iscsi_cmnd *cmnd);

extern void iscsi_scsi_queuecmnd(struct iscsi_cmnd *cmnd);
extern void iscsi_scsi_dequeuecmnd(struct iscsi_cmnd *cmnd);
extern void iscsi_scsi_execute(struct iscsi_cmnd *cmnd);

extern int start_worker_threads(struct iscsi_target *target);
extern void stop_worker_threads(struct iscsi_target *target);
extern void queue_cmnd(struct iscsi_cmnd *cmnd, process_cmnd_t *func);

extern int start_target_thread(struct iscsi_target *target);
extern void stop_target_thread(struct iscsi_target *target);
extern inline void wake_up_itargetd(struct iscsi_target *target);

extern int target_read_pages(struct iet_volume *volume, struct target_cmnd *cmnd);
extern int target_commit_pages(struct iet_volume *volume, struct target_cmnd *cmnd);
extern int target_sync_pages(struct iet_volume *volume, struct target_cmnd *cmnd);

extern void remove_from_itt_hashtable(struct iscsi_cmnd *cmnd);
extern inline struct iscsi_cmnd *iscsi_cmnd_get_rsp_cmnd(struct iscsi_cmnd *req_cmnd);
extern inline struct iscsi_cmnd *iscsi_cmnd_get_req_cmnd(struct iscsi_cmnd *rsp_cmnd);

extern void conns_info_show(struct seq_file *seq, struct iscsi_session *session);

/* target.c */
extern inline int iet_target_lock(struct iscsi_target *, int);
extern inline void iet_target_unlock(struct iscsi_target *);
struct iscsi_target *iet_target_lookup(u32 id);
extern int iet_target_add(struct target_info *info);
extern int iet_target_del(u32 id);
extern int iet_target_param_set(struct iscsi_target *target, struct param_info *info);
extern int iet_target_param_get(struct iscsi_target *target, struct param_info *info);
extern int iet_target_start(struct iscsi_target *target);
extern int iet_is_target_running(struct iscsi_target *target);

/* config.c */
extern void iet_procfs_init(void);
extern void iet_procfs_exit(void);
extern struct kevent *iet_event_get(int);
extern int iet_event_put(u32 tid, u64 sid, u32 cid, u32 state, int atomic);
extern int iet_info_show(struct seq_file *seq, iet_show_info_t *func);

/* session.c */
extern struct file_operations session_seq_fops;
extern struct iscsi_session *iet_session_lookup(struct iscsi_target *target, u64 sid);
extern int iet_session_add(struct iscsi_target *target, struct session_info *info);
extern int iet_session_del(struct iscsi_target *target, struct session_info *info);
extern int iet_session_free(struct iscsi_session *session);
extern int iet_session_param_set(struct iscsi_session *session, struct param_info *info);

/* volume.c */
extern struct file_operations volume_seq_fops;
extern struct iet_volume *iet_volume_lookup(struct iscsi_target *target, u32 lun);
extern int iet_volume_add(struct iscsi_target *target, struct volume_info *info);
extern int iet_volume_del(struct iet_volume *volume);

#define MAX_QUEUED_CMD_NR	32

#endif	/* __ISCSI_H__ */
