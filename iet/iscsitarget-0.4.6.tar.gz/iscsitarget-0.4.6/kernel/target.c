/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include "iscsi.h"
#include "iscsi_dbg.h"

static LIST_HEAD(target_list);
static DECLARE_MUTEX(target_list_sem);

struct target_type *target_type_array[] = {
	&disk_ops,
};

int target_active(struct iscsi_target *target)
{
	return target->nthread_info.task ? 1 : 0;
}

inline int target_lock(struct iscsi_target *target, int interruptible)
{
	int err = 0;

	if (interruptible)
		err = down_interruptible(&target->target_sem);
	else
		down(&target->target_sem);

	return err;
}

inline void target_unlock(struct iscsi_target *target)
{
	up(&target->target_sem);
}

struct iscsi_target *__iet_target_lookup(u32 id)
{
	struct iscsi_target *target;

	list_for_each_entry(target, &target_list, t_list) {
		if (target->tid == id)
			return target;
	}
	return NULL;
}

struct iscsi_target *target_lookup(u32 id)
{
	struct iscsi_target *target;

	down(&target_list_sem);
	target = __iet_target_lookup(id);
	up(&target_list_sem);

	return target;
}

static void iet_target_param_check(struct param_info *info)
{
	if (info->max_connections != 1)
		eprintk("MaxConnections (%u) should be 1.\n",
			info->max_connections);
	if (info->max_data_pdu_length < PAGE_CACHE_SIZE) {
		eprintk("MaxRecvDataSegmentLength (%u) < PAGE_CACHE_SIZE. "
			"Adjusting it to %lu.\n", info->max_data_pdu_length,
			PAGE_CACHE_SIZE);
		info->max_data_pdu_length = PAGE_CACHE_SIZE;
	} else if (get_pgcnt(info->max_data_pdu_length, 0) > ISCSI_CONN_IOV_MAX) {
		eprintk("MaxRecvDataSegmentLength (%u) > max. supported value. "
			"Adjusting it to %d.\n", info->max_data_pdu_length,
			(ISCSI_CONN_IOV_MAX - 1) << PAGE_CACHE_SHIFT);
		info->max_data_pdu_length = (ISCSI_CONN_IOV_MAX - 1) << PAGE_CACHE_SHIFT;
	}
	if (info->max_burst_length < PAGE_CACHE_SIZE) {
		eprintk("MaxBurstLength (%u) < PAGE_CACHE_SIZE. "
			"Adjusting it to %lu.\n", info->max_burst_length,
			PAGE_CACHE_SIZE);
		info->max_burst_length = PAGE_CACHE_SIZE;
	}

	if (info->first_burst_length < PAGE_CACHE_SIZE) {
		eprintk("FirstBurstLength (%u) < PAGE_CACHE_SIZE. "
			"Adjusting it to %lu.\n", info->first_burst_length,
			PAGE_CACHE_SIZE);
		info->first_burst_length = PAGE_CACHE_SIZE;
	}

	if (info->error_recovery_level != 0) {
		eprintk("ErrorRecoveryLevel (%u) must be 0.\n",
			info->error_recovery_level);
		info->error_recovery_level = 0;
	}
}

int target_param(struct iscsi_target *target, struct param_info *info, int set)
{
	struct iscsi_param *p = &target->default_param;

	if (set) {
		if (target_active(target)) {
			eprintk("Can't change params of a running target %u\n", target->tid);
			return -EALREADY;
		}
		iet_target_param_check(info);
		SET_PARAM(p, info);
		show_param(p);
	} else
		SET_PARAM(info, p);

	return 0;
}

#define MAX_NR_WTHREADS		128

static int iet_target_alloc(struct target_info *info)
{
	int err = -EINVAL, len;
	u32 id = info->tid;
	char *name = info->name;
	struct iscsi_target *target;

	dprintk(D_SETUP, "%u %s\n", id, name);

	if (info->type > ARRAY_SIZE(target_type_array)) {
		eprintk("Invalid target type %u %u\n", id, info->type);
		return err;
	}
	if (!(len = strlen(name))) {
		eprintk("The length of the target name is zero %u\n", id);
		return err;
	}
	if (!try_module_get(THIS_MODULE)) {
		eprintk("Fail to get module %u\n", id);
		return err;
	}

	if (!(target = kmalloc(sizeof(*target), GFP_KERNEL))) {
		err = -ENOMEM;
		goto out;
	}
	memset(target, 0, sizeof(*target));

	target->type = target_type_array[info->type];

	target->tid = id;
	memcpy(&target->default_param, &default_iscsi_param, sizeof(default_iscsi_param));

	if (!(target->name = kmalloc(len + 1, GFP_KERNEL))) {
		err = -ENOMEM;
		goto out;
	}
	memset(target->name, 0, len + 1);
	strcpy(target->name, name);

	if (info->nr_wthreads == 0 || info->nr_wthreads > MAX_NR_WTHREADS) {
		eprintk("0 < nr_wthreads (%u) < %u\n", info->nr_wthreads, MAX_NR_WTHREADS);
		info->nr_wthreads = 1;
	}
	target->wthread_info.nr_wthread = info->nr_wthreads;

	init_MUTEX(&target->target_sem);

	INIT_LIST_HEAD(&target->session_list);
	INIT_LIST_HEAD(&target->volumes);

	atomic_set(&target->nr_volumes, 0);

	list_add(&target->t_list, &target_list);

	nthread_init(target);
	wthread_init(target);

	return 0;
out:
	module_put(THIS_MODULE);

	kfree(target);

	return err;
}

int target_add(struct target_info *info)
{
	struct iscsi_target *target;
	int err = -EEXIST;

	down(&target_list_sem);
	if ((target = __iet_target_lookup(info->tid)))
		goto out;

	err = iet_target_alloc(info);
out:
	up(&target_list_sem);

	return err;
}

static int iet_target_free(struct iscsi_target *target)
{
	dprintk(D_SETUP, "%u\n", target->tid);

	if (!list_empty(&target->session_list))
		return -EBUSY;

	while (atomic_read(&target->target_sem.count) != 1)
		schedule();

	eprintk("Ready to remove target (%u)\n", target->tid);

	list_del(&target->t_list);

	wthread_stop(target);
	nthread_stop(target);

	while (!list_empty(&target->volumes)) {
		struct iet_volume *volume;
		volume = list_entry(target->volumes.next, struct iet_volume, list);
		volume_del(volume);
	}

	kfree(target->name);
	kfree(target);

	module_put(THIS_MODULE);

	return 0;
}

int target_del(u32 id)
{
	struct iscsi_target *target;
	int err;

	if ((err = down_interruptible(&target_list_sem)) < 0)
		return err;

	if (!(target = __iet_target_lookup(id))) {
		err = -ENOENT;
		goto out;
	}

	err = iet_target_free(target);

out:
	up(&target_list_sem);

	return err;
}

int target_start(struct iscsi_target *target)
{
	int err;

	if ((err = nthread_start(target)) < 0)
		return err;

	if ((err = wthread_start(target)) < 0) {
		nthread_stop(target);
	}

	return err;
}

int iet_info_show(struct seq_file *seq, iet_show_info_t *func)
{
	int err;
	struct iscsi_target *target;

	if ((err = down_interruptible(&target_list_sem)) < 0)
		return err;

	list_for_each_entry(target, &target_list, t_list) {
		seq_printf(seq, "tid:%u name:%s\n", target->tid, target->name);

		if ((err = target_lock(target, 1)) < 0)
			break;

		func(seq, target);

		target_unlock(target);
	}

	up(&target_list_sem);

	return 0;
}
