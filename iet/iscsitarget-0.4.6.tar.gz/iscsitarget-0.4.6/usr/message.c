/*
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

#include <errno.h>
#include <unistd.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>

#include "iscsid.h"
#include "ietadm.h"

int ietadm_request_listen(void)
{
	int fd, err;
	struct sockaddr_un addr;

	fd = socket(AF_LOCAL, SOCK_STREAM, 0);
	if (fd < 0)
		return fd;

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_LOCAL;
	memcpy((char *) &addr.sun_path + 1, IETADM_NAMESPACE, strlen(IETADM_NAMESPACE));

	if ((err = bind(fd, (struct sockaddr *) &addr, sizeof(addr))) < 0)
		return err;

	if ((err = listen(fd, 32)) < 0)
		return err;

	return fd;
}

static void __ietadm_request_handle(struct ietadm_request *req, struct ietadm_response *res)
{
	int err = 0;

	log_debug(1, "%u %u %llu %u %u %s", req->command, req->tid, (unsigned long long) req->sid,
		  req->cid, req->lun, req->u.tadd.name);

	switch (req->command) {
	case C_TARGET_ADD:
		if (target_alloc(req->tid, req->u.tadd.name) == NULL) {
			err = -EEXIST;
			break;
		}
		if ((err = target_add(ctrl_fd, req->tid)) < 0)
			break;
		if ((err = target_start(ctrl_fd, req->tid)) < 0)
			break;
		break;
	case C_USER_ADD:
		err = user_add(req->tid, req->u.uadd.name, req->u.uadd.pass,
			       req->u.uadd.global, req->u.uadd.auth_dir);
		break;
	default:
		break;
	}

	res->err = err;
}

int ietadm_request_handle(int accept_fd)
{
	struct sockaddr addr;
	struct ucred cred;
	int fd, err, len;
	struct ietadm_request req;
	struct ietadm_response res;

	memset(&res, 0, sizeof(res));
	len = sizeof(addr);
	if ((fd = accept(accept_fd, (struct sockaddr *) &addr, &len)) < 0) {
		if (errno == EINTR)
			err = -EINTR;
		else
			err = -EIO;

		goto out;
	}

	len = sizeof(cred);
	if ((err = getsockopt(fd, SOL_SOCKET, SO_PEERCRED, (void *) &cred, &len)) < 0) {
		res.err = -EPERM;
		goto send;
	}

	if (cred.uid || cred.gid) {
		res.err = -EPERM;
		goto send;
	}

	err = read(fd, &req, sizeof(req));
	if (err != sizeof(req)) {
		if (err >= 0)
			err = -EIO;
		goto out;
	}

	__ietadm_request_handle(&req, &res);

send:
	err = write(fd, &res, sizeof(res));
	if (err != sizeof(res))
		if (err >= 0)
			err = -EIO;
out:
	if (fd > 0)
		close(fd);
	return err;
}
