/*
 * Worker thread.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/slab.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"

#define NR_WORKER_THREADS 4

void queue_cmnd(struct iscsi_cmnd *cmnd, process_cmnd_t *func)
{
	struct worker_thread *wt;

	assert(cmnd);
	assert(cmnd->lun);
	assert(cmnd->lun->device);
	assert(!cmnd->func);

	wt = cmnd->lun->target->wt;

	spin_lock(&wt->worker_lock);
	cmnd->state = ISCSI_STATE_QUEUED;
	cmnd->func = func;
	assert(list_empty(&cmnd->list));
	list_add_tail(&cmnd->list, &wt->work_queue);
	spin_unlock(&wt->worker_lock);

	wake_up(&wt->thread_sleep);
}

static struct iscsi_cmnd * get_ready_cmnd(struct worker_thread *wt)
{
	struct iscsi_cmnd *cmnd = NULL;

	spin_lock(&wt->worker_lock);
	if (!list_empty(&wt->work_queue)) {
		cmnd = list_entry(wt->work_queue.next, struct iscsi_cmnd, list);
		list_del_init(&cmnd->list);
	}
	spin_unlock(&wt->worker_lock);

	return cmnd;
}

static int worker_thread(void *arg)
{
	struct worker_thread *wt = (struct worker_thread *) arg;
	struct iscsi_target *target = wt->target;
	struct iscsi_cmnd *cmnd;
	int wakeup = 0;
	u32 target_id, thread_id = 0;
	DECLARE_WAITQUEUE(wait, current);

	target_id = target->target.id;

	daemonize();
	reparent_to_init();

	spin_lock(&wt->worker_lock);
	thread_id = wt->threads++;

	sprintf(current->comm, "istiod%d/%u", target_id, thread_id);

	spin_lock_irq(&current->sigmask_lock);
	siginitsetinv(&current->blocked, 0);
	spin_unlock_irq(&current->sigmask_lock);

	dprintk(D_THREAD, "initialized %u/%u\n", target_id, thread_id);
	spin_unlock(&wt->worker_lock);

	add_wait_queue(&wt->thread_sleep, &wait);
	for (;;) {
		while (!list_empty(&wt->work_queue) &&
		       (cmnd = get_ready_cmnd(wt))) {
			process_cmnd_t *func;

			assert(cmnd);
			assert(cmnd->func);
			assert(cmnd->lun->device);

			func = cmnd->func;
			cmnd->func = NULL;
			func(cmnd);
		}

		if (!list_empty(&wt->work_queue))
			continue;
		if (wt->shutdown) {
			dprintk(D_THREAD, "exit %u/%u\n", target_id, thread_id);
			break;
		}

		set_current_state(TASK_INTERRUPTIBLE);
		if (list_empty(&wt->work_queue)) {
			dprintk(D_THREAD, "sleep %u/%u\n", target_id, thread_id);
			schedule();
			dprintk(D_THREAD, "wakeup %u/%u\n", target_id, thread_id);
		}
		set_current_state(TASK_RUNNING);
	}

	remove_wait_queue(&wt->thread_sleep, &wait);

	spin_lock(&wt->worker_lock);
	if (!--wt->threads)
		wakeup = 1;
	spin_unlock(&wt->worker_lock);

	dprintk(D_THREAD, "end %u/%u\n", target_id, thread_id);
	if (wakeup)
		wake_up(&wt->shutdown_wait);
	return 0;
}

void stop_worker_threads(struct iscsi_target *target)
{
	struct worker_thread *wt = target->wt;

	DECLARE_WAITQUEUE(wait, current);

	add_wait_queue(&wt->shutdown_wait, &wait);

	spin_lock(&wt->worker_lock);
	assert(wt->threads);
	assert(!wt->shutdown);
	wt->shutdown = 1;
	wake_up_all(&wt->thread_sleep);
	spin_unlock(&wt->worker_lock);

	wait_event(wt->shutdown_wait, !wt->threads);
	remove_wait_queue(&wt->shutdown_wait, &wait);

	assert(!wt->threads);

	kfree(wt);
}

int start_worker_threads(struct iscsi_target *target)
{
	int i, tid, err = 0;
	struct worker_thread *wt;

	wt = kmalloc(sizeof(*wt), GFP_KERNEL);
	if (!wt)
		return -ENOMEM;

	memset(wt, 0, sizeof(*wt));
	target->wt = wt;

	wt->target = target;
	spin_lock_init(&wt->worker_lock);
	INIT_LIST_HEAD(&wt->work_queue);

	init_waitqueue_head(&wt->thread_sleep);
	init_waitqueue_head(&wt->shutdown_wait);

	for (i = 0; i < NR_WORKER_THREADS; i++) {
		tid = kernel_thread(worker_thread, wt, CLONE_FS | CLONE_FILES);
		if (tid < 0) {
			err = tid;
			printk("%s: error %d\n", __FUNCTION__, err);

			stop_worker_threads(target);
			return err;
		}
	}

	while (wt->threads != NR_WORKER_THREADS) {
		__set_current_state(TASK_INTERRUPTIBLE);
		schedule_timeout(HZ/10);
	}

	return 0;
}
