/*
 * iSCSI target daemon.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/file.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include <net/sock.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

DECLARE_WAIT_QUEUE_HEAD(iscsi_ctl_wait);

enum daemon_state_bit {
	D_ACTIVE,
	D_DATA_READY,
};

enum iostate {
	IOSTATE_NEW, /* Must be zero. */

	IOSTATE_READ_HEADER,
	IOSTATE_READ_HCOMPLETE,
	IOSTATE_READ_AHS,
	IOSTATE_SET_DATA_LENGTH,
	IOSTATE_READ_DATA,

	IOSTATE_WRITE_BHS,
	IOSTATE_WRITE_AHS,
	IOSTATE_WRITE_DATA,

	IOSTATE_END,
};

inline void wake_up_itargetd(struct iscsi_target *target)
{
	set_bit(D_DATA_READY, &target->daemon.flags);
	wake_up(&target->daemon.wq);
}

static inline void iscsi_conn_init_read(struct iscsi_conn *conn, void *data, size_t len)
{
	len = (len + 3) & -4; // XXX ???
	conn->read_iov[0].iov_base = data;
	conn->read_iov[0].iov_len = len;
	conn->read_msg.msg_iov = conn->read_iov;
	conn->read_msg.msg_iovlen = 1;
	conn->read_size = (len + 3) & -4;
}

static struct iscsi_cmnd *create_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;

	cmnd = iscsi_cmnd_create(conn);
	assert(cmnd);
	cmnd->state = ISCSI_STATE_READ;
	iscsi_conn_init_read(conn, &cmnd->pdu.bhs, sizeof(cmnd->pdu.bhs));
	conn->read_state = IOSTATE_READ_HEADER;

	return cmnd;
}

static void iscsi_conn_read_ahs(struct iscsi_conn *conn, struct iscsi_cmnd *cmnd)
{
	assert(conn->read_cmnd == cmnd);
retry:
	assert(!cmnd->pdu.ahs);
	cmnd->pdu.ahs = kmalloc(cmnd->pdu.ahssize, GFP_KERNEL);
	if (!cmnd->pdu.ahs) {
		printk("%s: Out of memory\n", __FUNCTION__);
		yield();
		goto retry;
	}

	iscsi_conn_init_read(conn, cmnd->pdu.ahs, cmnd->pdu.ahssize);
}

static inline void iscsi_cmnd_get_length(struct iscsi_pdu *pdu)
{
#if defined(__BIG_ENDIAN)
	pdu->ahssize = pdu->bhs.length.ahslength * 4;
	pdu->datasize = pdu->bhs.length.datalength;
#elif defined(__LITTLE_ENDIAN)
	pdu->ahssize = (pdu->bhs.length & 0xff) * 4;
	pdu->datasize = be32_to_cpu(pdu->bhs.length & ~0xff);
#else
#error
#endif
}

static struct iscsi_cmnd * iscsi_get_send_cmnd(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd = NULL;

	spin_lock(&conn->list_lock);
	if (!list_empty(&conn->write_list)) {
		cmnd = list_entry(conn->write_list.next, struct iscsi_cmnd, list);
		list_del_init(&cmnd->list);
	}
	spin_unlock(&conn->list_lock);

	if (cmnd) {
		dprintk(D_IOD, "send (%p)\n", cmnd);
	}

	return cmnd;
}

static int is_data_available(struct iscsi_conn *conn)
{
	int avail, res;
	mm_segment_t oldfs;
	struct socket *sock = conn->sock;

	oldfs = get_fs();
	set_fs(get_ds());
	res = sock->ops->ioctl(sock, SIOCINQ, (unsigned long) &avail);
	set_fs(oldfs);
	return (res >= 0) ? avail : res;
}

void forward_iov(struct msghdr *msg, int len)
{
	while (msg->msg_iov->iov_len <= len) {
		len -= msg->msg_iov->iov_len;
		msg->msg_iov++;
		msg->msg_iovlen--;
	}

	msg->msg_iov->iov_base = (char *) msg->msg_iov->iov_base + len;
	msg->msg_iov->iov_len -= len;
}

int do_recv(struct iscsi_conn *conn, int state)
{
	mm_segment_t oldfs;
	struct socket *sock = conn->sock;
	struct msghdr msg;
	struct iovec iov[ISCSI_CONN_IOV_MAX];
	int i, len, res;

	dprintk(D_IOD, "%u %u\n", conn->cid, conn->read_state);
	assert(sock);

	msg.msg_iov = iov;
	msg.msg_iovlen = min(conn->read_msg.msg_iovlen, (size_t)ISCSI_CONN_IOV_MAX);
	for (i = 0, len = 0; i < msg.msg_iovlen; i++) {
		iov[i] = conn->read_msg.msg_iov[i];
		len += iov[i].iov_len;
	}

	oldfs = get_fs();
	set_fs(get_ds());
	res = sock_recvmsg(conn->sock, &msg, len, MSG_DONTWAIT | MSG_NOSIGNAL);

	set_fs(oldfs);

	dprintk(D_IOD, "%d %d %d\n", res, conn->read_state, state);

	if (res <= 0)
		goto out;

	conn->read_size -= res;

	if (conn->read_size)
		forward_iov(&conn->read_msg, res);
	else
		conn->read_state = state;
out:
	dprintk(D_IOD, "%d %d\n", res, conn->read_state);

	return res;
}

int recv_header(struct iscsi_conn *conn)
{
	return do_recv(conn, IOSTATE_READ_HCOMPLETE);
}

int recv_ahs(struct iscsi_conn *conn)
{
	iscsi_conn_read_ahs(conn, conn->read_cmnd);
	return do_recv(conn, IOSTATE_READ_DATA);
}

int recv_data(struct iscsi_conn *conn)
{
	return do_recv(conn, IOSTATE_END);
}

static int recv(struct iscsi_conn *conn)
{
	int res = 0;
	struct iscsi_cmnd *cmnd;

	dprintk(D_IOD,"%u %d\n", conn->cid, conn->read_state);

	cmnd = conn->read_cmnd;

	switch (conn->read_state) {
	case IOSTATE_NEW:
		assert(!cmnd);
		cmnd = conn->read_cmnd = create_cmnd(conn);
		/* fall through */
	case IOSTATE_READ_HEADER:
		res = recv_header(conn);
		dprintk(D_IOD,"%u %d %d\n", conn->cid, res, conn->read_state);
		if (res <= 0)
			break;
		if (conn->read_state != IOSTATE_READ_HCOMPLETE)
			break;
		/* fall through */
	case IOSTATE_READ_HCOMPLETE:
		assert(cmnd);
		dprintk(D_IOD,"%u %d %x\n", conn->cid, conn->read_state,
			cpu_to_be32(cmnd->pdu.bhs.itt));
		iscsi_cmnd_get_length(&cmnd->pdu);
		if (cmnd->pdu.ahssize)
			conn->read_state = IOSTATE_READ_AHS;
		else
			conn->read_state = IOSTATE_SET_DATA_LENGTH;

		dprintk(D_IOD,"%u %d %d\n", conn->cid, res, conn->read_state);
		if (conn->read_state != IOSTATE_READ_AHS)
			break;
		/* fall through */
	case IOSTATE_READ_AHS:
		res = recv_ahs(conn);
		if (res <= 0)
			break;
		if (conn->read_state != IOSTATE_SET_DATA_LENGTH)
			break;
		/* fall through */
	case IOSTATE_SET_DATA_LENGTH:
		res = 1;
		assert(cmnd);
		dprintk(D_IOD,"%u %d\n", conn->cid, conn->read_state);
		iscsi_cmnd_start_read(cmnd);
		if (cmnd->pdu.datasize)
			conn->read_state = IOSTATE_READ_DATA;
		else
			conn->read_state = IOSTATE_END;

		if (conn->read_state != IOSTATE_READ_DATA)
			break;
		/* fall through */
	case IOSTATE_READ_DATA:
		dprintk(D_IOD,"%u %d\n", conn->cid, conn->read_state);
		res = recv_data(conn);
		break;
	default:
		assert(0);
	}

	if (res < 0)
		return res;
	if (!res)
		return -EIO; /* disconnect */

	if (conn->read_state == IOSTATE_SET_DATA_LENGTH)
		return 1;

	if (conn->read_state != IOSTATE_END)
		return 0;

	dprintk(D_IOD,"%u %d %x %x\n", conn->cid, conn->read_state,
		cpu_to_be32(cmnd->pdu.bhs.itt), cmnd_opcode(cmnd));
	assert(!conn->read_size);
	iscsi_cmnd_finish_read(cmnd);
	conn->read_cmnd = NULL;
	conn->read_state = IOSTATE_NEW;

	return is_data_available(conn) > 0 ? 1 : 0;
}

static int do_send(struct iscsi_conn *conn)
{
	int res;

	dprintk(D_IOD,"%u %d %x\n", conn->cid, conn->write_state,
		cpu_to_be32(conn->write_cmnd->pdu.bhs.itt));
	res = iscsi_conn_write_data(conn);
	dprintk(D_IOD,"%u %d %u %d\n", conn->cid, conn->write_state,
		cpu_to_be32(conn->write_cmnd->pdu.bhs.itt), res);

	if (!conn->write_size)
		conn->write_state = IOSTATE_END;
	return res;
}

static int send(struct iscsi_conn *conn)
{
	int res = 0;
	struct iscsi_cmnd *cmnd = conn->write_cmnd;

	dprintk(D_IOD,"%u %d\n", conn->cid, conn->write_state);
	switch (conn->write_state) {
	case IOSTATE_NEW:
		assert(!cmnd);
		conn->write_cmnd = iscsi_get_send_cmnd(conn);
		if (!conn->write_cmnd)
			return 0;
		cmnd = conn->write_cmnd;
		conn->write_state = IOSTATE_WRITE_BHS;
		/* fall through */
	case IOSTATE_WRITE_BHS:
		iscsi_cmnd_start_write(cmnd);
		conn->write_state = IOSTATE_WRITE_DATA;
		/* fall through */
	case IOSTATE_WRITE_DATA:
		res = do_send(conn);
		break;
	}

	if (res < 0)
		return res;
	if (!res)
		return -EIO;

	if (conn->write_state != IOSTATE_END)
		return 1;

	assert(!conn->write_size);
	iscsi_cmnd_finish_write(cmnd);
	iscsi_cmnd_release(cmnd);
	conn->write_cmnd = NULL;
	conn->write_state = IOSTATE_NEW;

	return list_empty(&conn->write_list) ? 0 : 1;
}

static void process_io(struct iscsi_conn *conn)
{
	struct iscsi_target *target = conn->session->target;
	int res, max_nr_cmnd = 8;

	do {
		res = recv(conn);
		dprintk(D_IOD,"%u %d %d\n", conn->cid, conn->read_state, res);
		if (res < 0)
			break;
	} while (res > 0 && max_nr_cmnd-- > 0);

	if (res < 0) {
		switch (res) {
		case -EWOULDBLOCK:
			break;
		case -EINTR:
			set_bit(D_DATA_READY, &conn->session->target->daemon.flags);
			break;
		default:
			printk("%s(%d) %u %d\n", __FUNCTION__, __LINE__, conn->cid, res);
			iscsi_conn_closefd(conn);
			set_bit(D_DATA_READY, &conn->session->target->daemon.flags);
			break;
		}
	}

	if (res > 0 || is_data_available(conn) > 0)
		set_bit(D_DATA_READY, &target->daemon.flags);

	if (!test_bit(CONN_ACTIVE, &conn->state))
		return;

	do {
		res = send(conn);
		dprintk(D_IOD,"%u %d\n", conn->cid, conn->write_state);
		if (res < 0)
			break;
	} while (res > 0);

	if (res < 0) {
		switch (res) {
		case -EWOULDBLOCK:
			set_bit(D_DATA_READY, &conn->session->target->daemon.flags);
			break;
		case -EINTR:
			set_bit(D_DATA_READY, &conn->session->target->daemon.flags);
			break;
		default:
			printk("%s(%d) %u %d\n", __FUNCTION__, __LINE__, conn->cid, res);
			iscsi_conn_closefd(conn);
			set_bit(D_DATA_READY, &conn->session->target->daemon.flags);
			break;
		}
	}

	if (!list_empty(&conn->write_list) || conn->write_cmnd)
		set_bit(D_DATA_READY, &target->daemon.flags);

	return;
}

static void close_conn(struct iscsi_conn *conn)
{
	struct iscsi_session *session = conn->session;

	assert(conn);

	conn->sock->ops->shutdown(conn->sock, 2);

	if (conn->read_cmnd) {
		dprintk(D_SETUP,"%x %x\n",
			cmnd_opcode(conn->read_cmnd), cmnd_itt(conn->read_cmnd));
		iscsi_cmnd_remove(conn->read_cmnd);
		conn->read_cmnd = NULL;
	}

	if (conn->write_cmnd) {
		dprintk(D_SETUP,"%x %x\n",
			cmnd_opcode(conn->write_cmnd), cmnd_itt(conn->write_cmnd));
		iscsi_cmnd_finish_write(conn->write_cmnd);
		conn->write_cmnd = NULL;
	}

	write_lock(&conn->sock->sk->callback_lock);
	conn->sock->sk->state_change = session->target->old_state_change;
	conn->sock->sk->data_ready = session->target->old_data_ready;
	write_unlock(&conn->sock->sk->callback_lock);

	fput(conn->file);
	conn->file = NULL;
	conn->sock = NULL;

	clear_bit(CONN_CLOSING, &conn->state);
	set_bit(CONN_CLOSED, &conn->state);

	wake_up_interruptible(&iscsi_ctl_wait);
	wake_up(&shutdown_wq);
}

static int istd(void *arg)
{
	struct iscsi_target *target = arg;
	struct iscsi_daemon *d = &target->daemon;
	struct iscsi_conn *conn, *tmp;

	daemonize();
	reparent_to_init();

	spin_lock_irq(&current->sigmask_lock);
	siginitsetinv(&current->blocked, 0);
	spin_unlock_irq(&current->sigmask_lock);

	sprintf(current->comm, "istd%d", target->target.id);

	set_fs(KERNEL_DS);

	set_bit(D_ACTIVE, &d->flags);
	for (;;) {
		wait_event_interruptible(d->wq, test_bit(D_DATA_READY, &target->daemon.flags));
		clear_bit(D_DATA_READY, &target->daemon.flags);

		if (!test_bit(D_ACTIVE, &d->flags))
			break;

		spin_lock(&d->conn_lock);
		list_for_each_entry_safe(conn, tmp, &d->active_conns, poll_list) {
			if (test_bit(CONN_ACTIVE, &conn->state)) {
				spin_unlock(&d->conn_lock);

				process_io(conn);

				spin_lock(&d->conn_lock);
			} else {
				if (!test_bit(CONN_CLOSING, &conn->state))
					printk("%s(%d) BUG?\n", __FUNCTION__, __LINE__);

				list_del(&conn->poll_list);
				spin_unlock(&d->conn_lock);

				printk("%s(%d) close conn %u\n",
				       __FUNCTION__, __LINE__, conn->cid);
				put_closed_conn(conn);
				close_conn(conn);

				spin_lock(&d->conn_lock);
			}
		}
		spin_unlock(&d->conn_lock);
	}

	return 0;
}

int start_target_thread(struct iscsi_target *target)
{
	struct iscsi_daemon *d = &target->daemon;

	d->flags = 0;
	spin_lock_init(&d->conn_lock);
	INIT_LIST_HEAD(&d->active_conns);
	init_waitqueue_head(&d->wq);

	kernel_thread(istd, target, CLONE_FS | CLONE_FILES);
	while (!test_bit(D_ACTIVE, &d->flags)) {
		__set_current_state(TASK_INTERRUPTIBLE);
		schedule_timeout(HZ/10);
	}

	return 0;
}

void stop_target_thread(struct iscsi_target *target)
{
	clear_bit(D_ACTIVE, &target->daemon.flags);
	wake_up_itargetd(target);
}
