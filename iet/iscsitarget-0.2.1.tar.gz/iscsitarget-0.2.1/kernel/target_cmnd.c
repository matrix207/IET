/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/compiler.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <asm/uaccess.h>

#include "iscsi_dbg.h"
#include "target.h"
#include "target_device.h"

static kmem_cache_t *target_cmnd_cache;

struct target_cmnd *target_cmnd_alloc(void)
{
	struct target_cmnd *tcmnd;
	do {
		tcmnd = kmem_cache_alloc(target_cmnd_cache, GFP_KERNEL);
		if (!tcmnd)
			yield();
	} while (!tcmnd);

	dprintk(D_GENERIC, "%p\n", tcmnd);
	memset(tcmnd, 0, sizeof(*tcmnd));

	return tcmnd;
}

static inline void target_cmnd_free(struct target_cmnd *tcmnd)
{
	kmem_cache_free(target_cmnd_cache, tcmnd);
}

int target_alloc_pages(struct target_cmnd *cmnd, int count)
{
	int i;
	struct page *page;

	dprintk(D_GENERIC, "%p %d (%d)\n", cmnd, count, cmnd->pg_cnt);
	for (i = cmnd->pg_cnt; i < count; i++) {
		while (i >= TARGET_CMND_MAX_PAGES) {
			struct target_cmnd *tmp;

			if (!(tmp = cmnd->next)) {
				tmp = cmnd->next = target_cmnd_alloc();
			}
			cmnd = tmp;
			i = cmnd->pg_cnt;
			count -= TARGET_CMND_MAX_PAGES;
		}

		do {
			page = alloc_page(GFP_KERNEL);
			if (!page)
				yield();
		} while (!page);
		cmnd->u.pg.io_pages[i] = page;
	}
	cmnd->pg_cnt = i;

	return 0;
}

void target_free_pages(struct target_cmnd *tcmnd)
{
	struct target_cmnd *cmnd;
	int i;

	if (!tcmnd)
		return;
	dprintk(D_GENERIC, "%p %d\n", tcmnd, tcmnd->pg_cnt);
	do {
		for (i = 0; i < tcmnd->pg_cnt; i++) {
			__free_page(tcmnd->u.pg.io_pages[i]);
		}
		cmnd = tcmnd->next;
		dprintk(D_GENERIC, "%p\n", tcmnd);
		target_cmnd_free(tcmnd);
	} while ((tcmnd = cmnd));
}

static struct target_cmnd *target_cmnd_alloc_next(struct target_cmnd *tcmnd, unsigned long pg_idx)
{
	struct target_cmnd *cmnd;

	tcmnd->pg_cnt = TARGET_CMND_MAX_PAGES;
	if (!(cmnd = tcmnd->next)) {
		cmnd = tcmnd->next = target_cmnd_alloc();
		dprintk(D_GENERIC, "%p\n", cmnd);
		cmnd->u.pg.idx = pg_idx;
	}
	return cmnd;
}

static void alloc_iopages(struct target_cmnd *tcmnd, int nr)
{
	struct page *page = NULL;
	int i;

	for (i = 0; i < nr; i++) {
		assert(!page);
		assert(!tcmnd->u.pg.io_pages[i]);
		do {
			page = alloc_page(GFP_KERNEL);
			if (!page)
				yield();
		} while (!page);

		tcmnd->u.pg.io_pages[i] = page;
		dprintk(D_DATA, "%p %p %d\n", tcmnd, page, i);
		page = NULL;
	}
}

void target_alloc_read_pages(struct target_device *dev, struct target_cmnd *tcmnd)
{
	struct target_cmnd *last = tcmnd;
	unsigned long pg_idx;
	u32 pg_nr, pg_cnt;
	int i, nr, tcmnd_nr;

	pg_idx = tcmnd->u.pg.idx;
	pg_nr = (tcmnd->u.pg.size + tcmnd->u.pg.offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	tcmnd_nr = (pg_nr + TARGET_CMND_MAX_PAGES - 1) / TARGET_CMND_MAX_PAGES;

	dprintk(D_READ, "%p %d (%d) %lx,%x-%x\n",
		tcmnd, pg_nr, tcmnd_nr, pg_idx, tcmnd->u.pg.offset, tcmnd->u.pg.size);

	pg_cnt = pg_nr;
	for (i = 0; i < tcmnd_nr; i++) {
		if (!tcmnd) {
			tcmnd = target_cmnd_alloc_next(last, pg_idx);
		}
		if (i == tcmnd_nr - 1)
			nr = (pg_nr % TARGET_CMND_MAX_PAGES) ? : TARGET_CMND_MAX_PAGES;
		else
			nr = TARGET_CMND_MAX_PAGES;

		alloc_iopages(tcmnd, nr);

		pg_idx += TARGET_CMND_MAX_PAGES;

		pg_cnt -= nr;
		last = tcmnd;
		tcmnd = NULL;
	}
	assert(!pg_cnt);
}

int target_read_pages(struct target_device *dev, struct target_cmnd *tcmnd)
{
	return target_device_read(dev, tcmnd);
}

void target_init_iocmnd(struct target_device *dev, struct target_cmnd *tcmnd, loff_t offset, u32 size)
{
	tcmnd->u.pg.idx = offset >> PAGE_CACHE_SHIFT;
	tcmnd->u.pg.offset = offset & ~PAGE_CACHE_MASK;
	tcmnd->u.pg.size = size;

	/* This prevents the iscsi_cmnd_scsi_rsp to touch cmnd->data
	 * in the case of a WRITE cmnd. Rewrite this better later.
	 */
	tcmnd->pg_cnt = 1;

	tcmnd->u.pg.pos = offset;
}

void target_alloc_write_pages(struct target_device *dev, struct target_cmnd *tcmnd)
{
	struct target_cmnd *last = NULL;
	unsigned long pg_idx;
	u32 pg_nr, pg_cnt;
	int i, nr, tcmnd_nr;

	pg_idx = tcmnd->u.pg.idx;
	pg_nr = (tcmnd->u.pg.size + tcmnd->u.pg.offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	tcmnd_nr = (pg_nr + TARGET_CMND_MAX_PAGES - 1) / TARGET_CMND_MAX_PAGES;

	dprintk(D_WRITE, "%p %d (%d) %lx,%x-%x\n",
		tcmnd, pg_nr, tcmnd_nr, pg_idx, tcmnd->u.pg.offset, tcmnd->u.pg.size);

	pg_cnt = pg_nr;
	for (i = 0; i < tcmnd_nr; i++) {
		if (!tcmnd) {
			tcmnd = target_cmnd_alloc_next(last, pg_idx);
		}
		if (i == tcmnd_nr - 1)
			nr = (pg_nr % TARGET_CMND_MAX_PAGES) ? : TARGET_CMND_MAX_PAGES;
		else
			nr = TARGET_CMND_MAX_PAGES;

		alloc_iopages(tcmnd, nr);

		pg_idx += TARGET_CMND_MAX_PAGES;

		pg_cnt -= nr;
		last = tcmnd;
		tcmnd = NULL;
	}
	assert(!pg_cnt);
}

int target_commit_pages(struct target_device *dev, struct target_cmnd *tcmnd)
{
	return target_device_write(dev, tcmnd);
}

int target_sync_pages(struct target_device *dev, struct target_cmnd *tcmnd)
{
	return target_device_sync(dev, tcmnd);
}

void target_cleanup_iopages(struct target_cmnd *tcmnd)
{
	struct page *page;
	struct target_cmnd *last;
	int i, j, tcmnd_nr, nr;
	u32 pg_nr, pg_cnt;

	pg_nr = (tcmnd->u.pg.size + tcmnd->u.pg.offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	tcmnd_nr = (pg_nr + TARGET_CMND_MAX_PAGES - 1) / TARGET_CMND_MAX_PAGES;

	dprintk(D_DATA, "%p %d (%d) %lx,%x-%x\n",
		tcmnd, pg_nr, tcmnd_nr, tcmnd->u.pg.idx, tcmnd->u.pg.offset, tcmnd->u.pg.size);

	pg_cnt = pg_nr;
	for (i = 0; i < tcmnd_nr; i++) {
		if (i == tcmnd_nr - 1)
			nr = (pg_nr % TARGET_CMND_MAX_PAGES) ? : TARGET_CMND_MAX_PAGES;
		else
			nr = TARGET_CMND_MAX_PAGES;

		for (j = 0; j < nr; j++) {
			page = tcmnd->u.pg.io_pages[j];
			assert(page);
			dprintk(D_DATA, "%p %p %d %d\n", tcmnd, page, i, j);
			__free_page(page);
		}
		pg_cnt -= nr;
		last = tcmnd;
		tcmnd = tcmnd->next;
		target_cmnd_free(last);
	}
	assert(!pg_cnt);
}

int target_init(void)
{
	kmem_cache_t *cache;

	cache = kmem_cache_create("target_cmnd",
				  sizeof(struct target_cmnd), 0, 0, NULL, NULL);
	if (!cache)
		return -ENOMEM;

	target_cmnd_cache = cache;

	return 0;
}

void target_exit(void)
{
	kmem_cache_destroy(target_cmnd_cache);
}
