/*
 * Target device block I/O.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <linux/blkdev.h>
#include <linux/locks.h>
#include <asm/uaccess.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "target_device.h"
#include "iotype.h"

MODULE_AUTHOR("Fujita Tomonori <tomof@acm.org>");
MODULE_DESCRIPTION("iSCSI Target block I/O");
MODULE_LICENSE("GPL");

struct blockio_data {
	struct file *filp;
};

void end_blockio_sync(struct buffer_head *bh, int uptodate)
{
	struct page *page = bh->b_page;

	if (!uptodate)
		set_bit(PG_error, &page->flags);
	SetPageUptodate(page);

	mark_buffer_uptodate(bh, uptodate);
	unlock_buffer(bh);
	put_bh(bh);
}

void blockio_read(struct buffer_head *bh, struct page *page, kdev_t kdev,
		   unsigned long pg_idx, loff_t count, u32 offset)
{
	init_buffer(bh, end_blockio_sync, NULL);
	atomic_set(&bh->b_count, 1);
	set_bit(BH_Lock, &bh->b_state);
	set_bit(BH_Mapped, &bh->b_state);
	clear_bit(BH_Uptodate, &bh->b_state);
	clear_bit(BH_Dirty, &bh->b_state);

	set_bh_page(bh, page, 0);
	bh->b_size = PAGE_CACHE_SIZE;
	bh->b_dev = kdev;
	bh->b_blocknr = pg_idx;

	submit_bh(READ, bh);
	wait_on_buffer(bh);
}

void blockio_full_write(struct buffer_head *bh, struct page *page, kdev_t kdev,
			 unsigned long pg_idx, loff_t count, u32 offset)
{
	init_buffer(bh, end_blockio_sync, NULL);
	atomic_set(&bh->b_count, 1);
	set_bit(BH_Lock, &bh->b_state);
	set_bit(BH_Mapped, &bh->b_state);
	set_bit(BH_Uptodate, &bh->b_state);

	set_bh_page(bh, page, 0);
	bh->b_size = PAGE_CACHE_SIZE;
	bh->b_dev = kdev;
	bh->b_blocknr = pg_idx;

	submit_bh(WRITE, bh);
	wait_on_buffer(bh);
}

void blockio_partial_write(struct buffer_head *bh, struct page *page, kdev_t kdev,
			    unsigned long pg_idx, loff_t count, u32 offset)
{
	int blocksize = 512;
	unsigned long blocknr;
	u32 end = offset + count;

	if (offset & (blocksize - 1) || count & (blocksize - 1))
		printk("%s(%d) not aligned %p %lu %lld %u\n",
		       __FUNCTION__, __LINE__, page, pg_idx, count, offset);

	blocknr = pg_idx * (PAGE_SIZE / blocksize);
	blocknr += offset / blocksize;

	do {
		init_buffer(bh, end_blockio_sync, NULL);
		atomic_set(&bh->b_count, 1);
		set_bit(BH_Lock, &bh->b_state);
		set_bit(BH_Mapped, &bh->b_state);
		set_bit(BH_Uptodate, &bh->b_state);

		set_bh_page(bh, page, offset);
		bh->b_size = blocksize;
		bh->b_dev = kdev;
		bh->b_blocknr = blocknr++;

		submit_bh(WRITE, bh);
		wait_on_buffer(bh);

		offset += blocksize;
	} while (offset < end);
}

void blockio_write(struct buffer_head *bh, struct page *page, kdev_t kdev,
		    unsigned long pg_idx, loff_t count, u32 offset)
{
	u32 end = offset + count;
	assert(end <= PAGE_CACHE_SIZE);

	if (end < PAGE_CACHE_SIZE || offset)
		blockio_partial_write(bh, page, kdev, pg_idx, count, offset);
	else
		blockio_full_write(bh, page, kdev, pg_idx, count, offset);
}


int blockio_make_request(struct target_device *dev, struct target_cmnd *tcmnd, int rw)
{
	struct blockio_data *p = (struct blockio_data *) dev->private;
	struct buffer_head *bh;
	struct file *filp;
	struct page *page;
	unsigned long pg_idx;
	u32 pg_nr, pg_cnt, offset, size;
	loff_t ppos, count;
	int i, j, tcmnd_nr, nr;
	kdev_t kdev;

	assert(p);
	filp = p->filp;
	kdev = filp->f_dentry->d_inode->i_rdev;

	size = tcmnd->u.pg.size;
	offset= tcmnd->u.pg.offset;

	pg_idx = tcmnd->u.pg.idx;
	pg_nr = (size + offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
	tcmnd_nr = (pg_nr + TARGET_CMND_MAX_PAGES - 1) / TARGET_CMND_MAX_PAGES;

	ppos = (loff_t) pg_idx << PAGE_CACHE_SHIFT;
	ppos += offset;
	assert(tcmnd->u.pg.pos == (u32) ppos);

	pg_cnt = pg_nr;
	for (i = 0; i < tcmnd_nr; i++) {
		assert(tcmnd);
		if (i == tcmnd_nr - 1)
			nr = (pg_nr % TARGET_CMND_MAX_PAGES) ? : TARGET_CMND_MAX_PAGES;
		else
			nr = TARGET_CMND_MAX_PAGES;

		for (j = 0; j < nr; j++) {
			page = tcmnd->u.pg.io_pages[j];
			assert(page);

			if (offset + size > PAGE_SIZE)
				count = PAGE_SIZE - offset;
			else
				count = size;

			do {
				bh = get_unused_buffer_head(0);
				if (!bh)
					yield();
			} while (!bh);
			assert(bh);

			if (rw == READ)
				blockio_read(bh, page, kdev, pg_idx, count, offset);
			else
				blockio_write(bh, page, kdev, pg_idx, count, offset);

			assert(atomic_read(&bh->b_count) == 0);
			init_buffer(bh, NULL, NULL);
			bh->b_state = 0;
			put_unused_buffer_head(bh);

			size -= count;
			offset = 0;
			pg_idx++;
		}
		pg_cnt -= nr;
		tcmnd = tcmnd->next;
	}
	assert(!size);
	assert(!pg_cnt);

	return 0;
}

int blockio_sync(struct target_device *dev, struct target_cmnd *tcmnd)
{
	return 0;
}

int blockio_attach(struct target_device *dev, const char *path)
{
	int res = 0;
	struct blockio_data *p;
	struct file *filp;
	mm_segment_t oldfs;
	kdev_t kdev;
	struct inode *inode;

	if (dev->private) {
		printk("already attached ? %d\n", dev->id);
		return -EBUSY;
	}

	p = kmalloc(sizeof(*p), GFP_KERNEL);
	if (!p)
		return -ENOMEM;

	oldfs = get_fs();
	set_fs(get_ds());
	filp = filp_open(path, O_RDWR|O_LARGEFILE, 0);
	set_fs(oldfs);
	if (IS_ERR(filp)) {
		printk("%s(%d) can't open %s\n", __FUNCTION__, __LINE__, path);
		res = PTR_ERR(filp);
		goto fail;
	}

	inode = filp->f_dentry->d_inode;
	if (!S_ISBLK(inode->i_mode)) {
		printk("%s(%d) %s is not a block file\n", __FUNCTION__, __LINE__, path);
		res = -EINVAL;
		goto fail;
	}

	kdev = inode->i_rdev;
	if (!blk_size[MAJOR(kdev)]) {
		printk("%s(%d) blk_size[kdev] is null\n", __FUNCTION__, __LINE__);
		filp_close(filp, NULL);
		res = -ENODEV;
		goto fail;
	}

	target_device_setup(dev, kdev);
	p->filp = filp;

	dev->private = p;

	return res;
fail:
	kfree(p);
	return res;
}

void blockio_detach(struct target_device *dev)
{
	struct blockio_data *p = (struct blockio_data *) dev->private;

	assert(p);
	filp_close(p->filp, NULL);
	kfree(p);
	dev->private = NULL;
}

static struct iotype blockio =
{
	.name = "blockio",
	.owner = THIS_MODULE,
	.attach = blockio_attach,
	.make_request = blockio_make_request,
	.sync = blockio_sync,
	.detach = blockio_detach,
};

static int __init init_blockio(void)
{
	int res;

	res = register_iotype(&blockio);
	if (!res)
		printk("%s(%d) register %s\n",
		       __FUNCTION__, __LINE__, blockio.name);
	else
		printk("%s(%d) failed to register %s\n",
		       __FUNCTION__, __LINE__, blockio.name);

	return res;
}

static void __exit exit_blockio(void)
{
	printk("%s(%d) unregister %s\n", __FUNCTION__, __LINE__, blockio.name);
	unregister_iotype(&blockio);
}

EXPORT_NO_SYMBOLS;

module_init(init_blockio);
module_exit(exit_blockio);
