/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#ifndef __TARGET_DEVICE_H__
#define __TARGET_DEVICE_H__

#include <linux/version.h>
#include <linux/list.h>
#include <linux/wait.h>

struct target_device {
	struct list_head list;
	int id;
	atomic_t usage;
	char *name;

	int blk_shift;
	int blk_cnt;

	struct proc_dir_entry *proc_dir;

	struct iotype *iotype;
	void *private;
};

extern int alloc_target_device(u32, const char *, const char *,
			       int (*)(struct target_device *));
extern int free_target_device(u32, void (*)(struct target_device *));

extern struct target_device *target_device_get(u32 dev_id);
extern void target_device_put(struct target_device *dev);

extern void target_device_setup(struct target_device *dev, kdev_t kdev);

extern int target_device_read(struct target_device *dev, struct target_cmnd *tcmnd);
extern int target_device_write(struct target_device *dev, struct target_cmnd *tcmnd);
extern int target_device_sync(struct target_device *dev, struct target_cmnd *tcmnd);

#endif	/* __TARGET_DEVICE_H__ */
