/*
 * Target device midle layer.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/stat.h>
#include <linux/pagemap.h>
#include <linux/blkdev.h>
#include <linux/init.h>

#include "iscsi_dbg.h"
#include "target.h"
#include "target_device.h"
#include "iotype.h"

static DECLARE_MUTEX(target_device_sem);
static LIST_HEAD(target_device_list);

static struct target_device *iscsi_device_lookup(u32 id)
{
	struct target_device *dev;

	list_for_each_entry(dev, &target_device_list, list) {
		if (dev->id == id)
			return dev;
	}
	return NULL;
}

struct target_device *target_device_get(u32 dev_id)
{
	struct target_device *dev;

	down(&target_device_sem);

	dev = iscsi_device_lookup(dev_id);

	if (dev)
		atomic_inc(&dev->usage);

	up(&target_device_sem);

	return dev;
}

void target_device_put(struct target_device *dev)
{
	atomic_dec(&dev->usage);
	return;
}

static int __alloc_target_device(u32 id, const char *path, const char *iotype,
				 int (*constructor)(struct target_device *))
{
	int res;
	struct target_device *dev;
	struct iotype *iot;

	if (iotype) {
		iot = get_iotype(iotype);
	} else {
		printk("We use the fileio mode, since I/O mode is not specified.\n");
		iot = get_iotype("fileio");
	}
	if (!iot) {
		printk("can't find %s iotype\n", iotype);
		return -EINVAL;
	}

	dev = kmalloc(sizeof(*dev), GFP_KERNEL);
	if (!dev) {
		assert(iot);
		put_iotype(iot);
		return -ENOMEM;
	}
	memset(dev, 0, sizeof(*dev));

	dev->id = id;
	dev->iotype = iot;
	res = iot->attach(dev, path);

	if (res < 0) {
		printk("%s(%d) failed low device\n", __FUNCTION__, __LINE__);
		put_iotype(iot);
		kfree(dev);
		return res;
	}

	dev->name = kmalloc(strlen(path) + 1, GFP_KERNEL);
	if (!dev->name) {
		put_iotype(iot);
		kfree(dev);
		return -ENOMEM;
	}
	memset(dev->name, 0, strlen(path) + 1);
	memcpy(dev->name, path, strlen(path));

	assert(dev->private);
	dprintk(D_SETUP, "%s %u %s %s\n", !res ? "succeed" : "fail", id, path, iotype);

	list_add(&dev->list, &target_device_list);

	constructor(dev);

	return 0;
}

int alloc_target_device(u32 id, const char *path, const char *iotype,
			int (*constructor)(struct target_device *))
{
	int res = 0;
	struct target_device *dev;

	down(&target_device_sem);

	dev = iscsi_device_lookup(id);

	if (dev) {
		res = -EEXIST;
		goto out;
	}

	res = __alloc_target_device(id, path, iotype, constructor);

out:
	up(&target_device_sem);

	return res;
}

int free_target_device(u32 id, void (*destructor)(struct target_device *))
{
	int res = 0;
	struct iotype *iot;
	struct target_device *dev;

	down(&target_device_sem);

	dev = iscsi_device_lookup(id);

	if (!dev) {
		res = -ENOENT;
		goto out;
	}

	if (atomic_read(&dev->usage)) {
		res = -EBUSY;
		goto out;
	}

	iot = dev->iotype;
	assert(iot);
	iot->detach(dev);
	put_iotype(iot);

	destructor(dev);

	list_del(&dev->list);

	kfree(dev->name);
	kfree(dev);
out:
	up(&target_device_sem);
	return res;
}

int target_device_read(struct target_device *dev, struct target_cmnd *tcmnd)
{
	struct iotype *iot = dev->iotype;
	assert(iot);
	return iot->make_request(dev, tcmnd, READ);
}

int target_device_write(struct target_device *dev, struct target_cmnd *tcmnd)
{
	struct iotype *iot = dev->iotype;
	assert(iot);
	return iot->make_request(dev, tcmnd, WRITE);
}

int target_device_sync(struct target_device *dev, struct target_cmnd *tcmnd)
{
	struct iotype *iot = dev->iotype;
	assert(iot);
	return iot->sync(dev, tcmnd);
}

void target_device_setup(struct target_device *dev, kdev_t kdev)
{
	dev->blk_shift = 9;
	dev->blk_cnt = blk_size[MAJOR(kdev)][MINOR(kdev)];
	if (dev->blk_shift < 10)
		dev->blk_cnt <<= 10 - dev->blk_shift;
	else
		dev->blk_cnt >>= dev->blk_shift - 10;
}
