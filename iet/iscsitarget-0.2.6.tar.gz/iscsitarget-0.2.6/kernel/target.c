/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

static LIST_HEAD(target_list);
static DECLARE_MUTEX(target_list_sem);

inline void write_lock_target(struct iscsi_target *target)
{
	down_write(&target->target_sem);
}

inline void write_unlock_target(struct iscsi_target *target)
{
	up_write(&target->target_sem);
}

inline void read_lock_target(struct iscsi_target *target)
{
	down_read(&target->target_sem);
}

inline void read_unlock_target(struct iscsi_target *target)
{
	up_read(&target->target_sem);
}

static struct iscsi_target *iscsi_target_lookup(u32 id)
{
	struct iscsi_target *target;

	list_for_each_entry(target, &target_list, target.list) {
		if (target->target.id == id)
			return target;
	}
	return NULL;
}

static int do_iscsi_target_create(u32 id, const char *name)
{
	int res = -ENOMEM;
	struct iscsi_target *target;

	dprintk(D_SETUP, "%u %s\n", id, name);
	target = kmalloc(sizeof(*target), GFP_KERNEL);
	if (!target)
		return res;
	memset(target, 0, sizeof(*target));

	target->target.id = id;
	memcpy(&target->default_param, &default_iscsi_param, sizeof(default_iscsi_param));

	target->name = kmalloc(strlen(name) + 1, GFP_KERNEL);
	if (!target->name)
		goto out;
	strcpy(target->name, name);

	init_rwsem(&target->target_sem);

	INIT_LIST_HEAD(&target->session_list);
	INIT_LIST_HEAD(&target->lun_list);

	atomic_set(&target->lun_cnt, 0);

	list_add(&target->target.list, &target_list);

	start_target_thread(target);
	start_worker_threads(target);

	iscsi_target_proc_init(target);

	MOD_INC_USE_COUNT;

	return 0;
out:
	kfree(target);
	return res;
}

int iscsi_target_create(u32 id, const char *name)
{
	struct iscsi_target *target;
	int res = -EEXIST;

	down(&target_list_sem);
	target = iscsi_target_lookup(id);

	if (target)
		goto out;

	res = do_iscsi_target_create(id, name);
out:
	up(&target_list_sem);
	return res;
}

static int do_iscsi_target_remove(struct iscsi_target *target)
{
	dprintk(D_SETUP, "%u\n", target->target.id);

	write_lock_target(target);
	if (!list_empty(&target->session_list) || !list_empty(&target->lun_list)) {
		write_unlock_target(target);
		return -EBUSY;
	}

	iscsi_target_proc_exit(target);

	stop_worker_threads(target);

	stop_target_thread(target);

	list_del(&target->target.list);

	write_unlock_target(target);

	kfree(target->name);
	kfree(target->alias);
	kfree(target);

	MOD_DEC_USE_COUNT;

	return 0;
}

int iscsi_target_remove(u32 id)
{
	struct iscsi_target *target;
	int res = -ENOENT;

	down(&target_list_sem);
	target = iscsi_target_lookup(id);
	if (!target)
		goto out;
	res = do_iscsi_target_remove(target);

out:
	up(&target_list_sem);

	return res;
}
