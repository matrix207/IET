/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#ifndef __TARGET_H__
#define __TARGET_H__

#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/wait.h>

struct target_device;
struct target_cmnd;

struct target {
	struct list_head list;
	u32 id;

	struct proc_dir_entry *proc_dir;
};

#define TARGET_CMND_MAX_PAGES	8
#define TARGET_CMND_MAX_DATA	(TARGET_CMND_MAX_PAGES * PAGE_CACHE_SIZE)

struct target_cmnd {
	struct target_cmnd *next;
	u32 pg_cnt;
	union {
		struct {
			unsigned long idx;
			u32 offset;
			u32 size;
			u32 pos;

			struct page *io_pages[TARGET_CMND_MAX_PAGES];
		} pg;
		char data[1];
	} u;
};

extern struct target_cmnd *target_cmnd_alloc(void);
extern int target_alloc_pages(struct target_cmnd *cmnd, int count);
extern void target_free_pages(struct target_cmnd *cmnd);
extern void target_init_iocmnd(struct target_device *dev, struct target_cmnd *tcmnd, loff_t offset, u32 size);
extern void target_alloc_read_pages(struct target_device *dev, struct target_cmnd *cmnd);
extern int target_read_pages(struct target_device *dev, struct target_cmnd *cmnd);
extern void target_alloc_write_pages(struct target_device *dev, struct target_cmnd *tcmnd);
extern int target_commit_pages(struct target_device *dev, struct target_cmnd *cmnd);
extern int target_sync_pages(struct target_device *dev, struct target_cmnd *cmnd);
extern void target_cleanup_iopages(struct target_cmnd *cmnd);
extern int target_init(void);
extern void target_exit(void);

extern struct iotype *get_iotype(const char *name);
extern void put_iotype(struct iotype *iot);

#endif	/* __TARGET_H__ */
