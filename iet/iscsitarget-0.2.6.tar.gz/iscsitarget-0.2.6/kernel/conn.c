/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/file.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include <net/sock.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

static spinlock_t closed_conn_lock = SPIN_LOCK_UNLOCKED;
static LIST_HEAD(closed_conn_list);
DECLARE_WAIT_QUEUE_HEAD(shutdown_wq);

void put_closed_conn(struct iscsi_conn *conn)
{
	dprintk(D_EXIT, "%u\n", conn->cid);

	spin_lock(&closed_conn_lock);
	list_add_tail(&conn->poll_list, &closed_conn_list);
	spin_unlock(&closed_conn_lock);
}

struct iscsi_conn *get_closed_conn(int del)
{
	struct iscsi_conn *conn = ERR_PTR(-EAGAIN);

	spin_lock(&closed_conn_lock);

	if (list_empty(&closed_conn_list))
		goto out;

	conn = list_entry(closed_conn_list.next, struct iscsi_conn, poll_list);

	if (del)
		list_del_init(&conn->poll_list);
out:
	spin_unlock(&closed_conn_lock);

	if (conn == ERR_PTR(-EAGAIN)) {
		dprintk(D_EXIT, "%s\n", "NULL");
	} else {
		dprintk(D_EXIT, "%u\n", conn->cid);
	}
	return conn;
}

static struct iscsi_conn *iscsi_session_lookup_conn(struct iscsi_session *session, u16 cid)
{
	struct iscsi_conn *conn;

	list_for_each_entry(conn, &session->conn_list, list) {
		if (conn->cid == cid)
			return conn;
	}
	return NULL;
}


static void cleanup_write_list(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;
	LIST_HEAD(d_list);
	int count = 0;

	spin_lock(&conn->list_lock);

	if (list_empty(&conn->write_list)) {
		spin_unlock(&conn->list_lock);
		return;
	}

	list_splice_init(&conn->write_list, &d_list);
	assert(list_empty(&conn->write_list));

	spin_unlock(&conn->list_lock);

	list_for_each_entry_safe(cmnd, tmp, &d_list, list) {
		list_del_init(&cmnd->list);
		iscsi_cmnd_release(cmnd);
		count++;
	}
	dprintk(D_SETUP, "%p %d\n", conn, count);
}

static void cleaup_ready_lists(struct iscsi_conn *conn)
{
	struct worker_thread *wt = conn->session->target->wt;

	struct iscsi_cmnd *cmnd, *tmp;
	process_cmnd_t *func;
	int count = 0;

	LIST_HEAD(d_list);

	/* FIXME */
	spin_lock(&wt->worker_lock);
	list_for_each_entry_safe(cmnd, tmp, &wt->work_queue, list) {
		if (cmnd->conn == conn) {
			list_move(&cmnd->list, &d_list);
			dprintk(D_SETUP, "move %p,%d,%x\n",
				cmnd, cmnd->state, cmnd_opcode(cmnd));
		} else {
			dprintk(D_SETUP, "%p,%d,%x\n", cmnd, cmnd->state, cmnd_opcode(cmnd));
		}
	}
	spin_unlock(&wt->worker_lock);

	list_for_each_entry_safe(cmnd, tmp, &d_list, list) {
		list_del_init(&cmnd->list);

		assert(cmnd->func);
		assert(cmnd->lun->device);

		func = cmnd->func;
		func(cmnd);
		count++;
	}

	dprintk(D_SETUP, "%p %d\n", conn, count);
}


static void cleanup_r2t_cmnds(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;
	int count = 0;
	u8 opcode;

	list_for_each_entry_safe(cmnd, tmp, &conn->pdu_list, conn_list) {
		opcode = cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK;
		dprintk(D_SETUP, "%p,%d,%x\n", cmnd, cmnd->state, opcode);

		if (opcode == ISCSI_OP_R2T) {
			iscsi_session_remove_ttt(cmnd);
			count++;
		}
	}

	dprintk(D_SETUP, "%d r2t cmnds were removed\n", count);
}

static void cleanup_r2t_req_cmnds(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;
	int count = 0;
	u8 opcode;

	list_for_each_entry_safe(cmnd, tmp, &conn->pdu_list, conn_list) {
		opcode = cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK;

		dprintk(D_SETUP, "%p,%d,%x\n", cmnd, cmnd->state, opcode);

		if (opcode == ISCSI_OP_SCSI_CMD && cmnd->state == ISCSI_STATE_SEND_RTT) {
			assert(list_empty(&cmnd->pdu_list));
			iscsi_cmnd_release(cmnd);
			count++;
		}
	}

	dprintk(D_SETUP, "%d r2t req cmnds were removed\n", count);
}

static void dump_cmnds(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd, *tmp;
	int count = 0;

	list_for_each_entry_safe(cmnd, tmp, &conn->pdu_list, conn_list) {
		dprintk(D_SETUP, "%p,%d,%x\n", cmnd, cmnd->state, cmnd_opcode(cmnd));
		count++;
	}

	dprintk(D_SETUP, "%d cmnds were removed\n", count);
}

int flush_cmnds(struct iscsi_conn *conn)
{
	dprintk(D_SETUP, "%p %#Lx %u\n", conn->session, conn->session->sid, conn->cid);

	if (!list_empty(&conn->write_list))
		cleanup_write_list(conn);

	cleaup_ready_lists(conn);

	if (conn->cmnd_cnt) {
		dprintk(D_SETUP, "%u cmnds remains\n", conn->cmnd_cnt);
		cleanup_r2t_cmnds(conn);
		dprintk(D_SETUP, "%u cmnds remains\n", conn->cmnd_cnt);
		cleanup_r2t_req_cmnds(conn);
		dprintk(D_SETUP, "%u cmnds remains\n", conn->cmnd_cnt);
		dump_cmnds(conn);
	} else
		dprintk(D_SETUP, "luckily no cmnd %Lx %u\n", conn->session->sid, conn->cid);

	iscsi_conn_proc_exit(conn);

	kfree(conn);

	return 0;
}

static void wait_conn_closed(struct iscsi_conn *conn)
{
	iscsi_conn_closefd(conn);
	wait_event(shutdown_wq, test_bit(CONN_CLOSED, &conn->state));
}

static int do_iscsi_conn_create(struct iscsi_session *session, u16 cid)
{
	struct iscsi_conn *conn;

	dprintk(D_SETUP, "%#Lx:%u\n", session->sid, cid);
	conn = kmalloc(sizeof(*conn), GFP_KERNEL);
	if (!conn)
		return -ENOMEM;
	memset(conn, 0, sizeof(*conn));

	set_bit(CONN_NEW, &conn->state);
	conn->session = session;
	conn->cid = cid;
	spin_lock_init(&conn->list_lock);
	conn->cmnd_cnt = 0;
	INIT_LIST_HEAD(&conn->pdu_list);
	INIT_LIST_HEAD(&conn->write_list);
	INIT_LIST_HEAD(&conn->poll_list);

	list_add(&conn->list, &session->conn_list);

	iscsi_conn_proc_init(conn);

	return 0;
}

int iscsi_conn_create(struct iscsi_session *session, u16 cid)
{
	struct iscsi_conn *conn;
	int res = -EEXIST;

	down(&session->conn_list_sem);
	conn = iscsi_session_lookup_conn(session, cid);
	if (conn)
		goto out;
	res = do_iscsi_conn_create(session, cid);
out:
	up(&session->conn_list_sem);

	return res;
}

static int do_iscsi_conn_remove(struct iscsi_conn *conn)
{
	dprintk(D_SETUP, "%p %#Lx %u\n", conn->session, conn->session->sid, conn->cid);

	wait_conn_closed(conn);
	assert(test_bit(CONN_CLOSED, &conn->state));

	assert(list_empty(&conn->poll_list));
	list_del(&conn->list);

	dprintk(D_SETUP, "%p %#Lx %u\n", conn->session, conn->session->sid, conn->cid);
	flush_cmnds(conn);

	return 0;
}

int iscsi_conn_remove(struct iscsi_session *session, u16 cid)
{
	struct iscsi_conn *conn;
	int res = -ENOENT;

	dprintk(D_SETUP, "%u\n", cid);
	down(&session->conn_list_sem);
	conn = iscsi_session_lookup_conn(session, cid);
	if (!conn)
		goto out;
	res = do_iscsi_conn_remove(conn);

out:
	up(&session->conn_list_sem);
	return res;
}

static void iscsi_state_change(struct sock *sk)
{
	struct iscsi_target *target = sk->user_data;

	target->old_state_change(sk);
	wake_up_itargetd(target);
}

static void iscsi_data_ready(struct sock *sk, int len)
{
	struct iscsi_target *target = sk->user_data;

	target->old_data_ready(sk, len);
	wake_up_itargetd(target);
}

static void iscsi_bind_socket(struct iscsi_conn *conn)
{
	struct iscsi_session *session = conn->session;
	struct iscsi_target *target = session->target;

	dprintk(D_GENERIC, "%llu\n", session->sid);
	conn->sock = &conn->file->f_dentry->d_inode->u.socket_i;
	conn->sock->sk->user_data = target;

	write_lock(&conn->sock->sk->callback_lock);
	target->old_state_change = conn->sock->sk->state_change;
	conn->sock->sk->state_change = iscsi_state_change;

	target->old_data_ready = conn->sock->sk->data_ready;
	conn->sock->sk->data_ready = iscsi_data_ready;
	write_unlock(&conn->sock->sk->callback_lock);
}

int iscsi_conn_takefd(struct iscsi_conn *conn, int fd)
{
	struct iscsi_session *session = conn->session;
	struct iscsi_target *target = session->target;

	dprintk(D_SETUP, "%d\n", fd);

	if (!test_and_clear_bit(CONN_NEW, &conn->state))
		return -EINVAL;

	set_bit(CONN_ACTIVE, &conn->state);
	conn->file = fget(fd);
	iscsi_bind_socket(conn);

	assert(list_empty(&conn->poll_list));

	spin_lock(&target->daemon.conn_lock);
	list_add(&conn->poll_list, &target->daemon.active_conns);
	spin_unlock(&target->daemon.conn_lock);

	wake_up_itargetd(conn->session->target);

	return 0;
}

void iscsi_conn_closefd(struct iscsi_conn *conn)
{
	if (test_and_clear_bit(CONN_ACTIVE, &conn->state))
		set_bit(CONN_CLOSING, &conn->state);
}
