/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#ifndef ISCSID_H
#define ISCSID_H

#include <sys/types.h>
#include <sys/ioctl.h>

#include "config.h"
#include "iscsi_hdr.h"
#include "iet_u.h"

#define ISCSI_TARGET_DEFAULT_PORT	3260

struct PDU {
	struct iscsi_hdr bhs;
	void *ahs;
	unsigned int ahssize;
	void *data;
	unsigned int datasize;
};

struct session_param {
	u32 flags;
	u32 max_connections;
	u32 max_data_pdu_length;
	u32 max_burst_length;
	u32 first_burst_length;
	u32 default_wait_time;
	u32 default_retain_time;
	u32 max_outstanding_r2t;
	u32 error_recovery_level;
	u32 header_digest;
	u32 data_digest;
	u32 max_sessions;
};

#define SESSION_FLG_INITIAL_R2T		0x0001
#define SESSION_FLG_IMMEDIATE_DATA	0x0002
#define SESSION_FLG_DATA_PDU_INORDER	0x0004
#define SESSION_FLG_DATA_SEQUENCE_INORDER 0x0008

#define IET_PARAM_INIT (struct session_param) {				\
	.flags			= SESSION_FLG_INITIAL_R2T		\
		 		| SESSION_FLG_DATA_PDU_INORDER		\
		 		| SESSION_FLG_DATA_SEQUENCE_INORDER,	\
	.max_connections 	= 1,					\
	.max_data_pdu_length 	= 8192,					\
	.max_burst_length 	= 262144,				\
	.first_burst_length 	= 65536,				\
	.default_wait_time 	= 2,					\
	.default_retain_time 	= 20,					\
	.max_outstanding_r2t 	= 8,					\
	.error_recovery_level 	= 0,					\
	.header_digest	 	= 0,					\
	.data_digest	 	= 0,					\
	.max_sessions	 	= 0,					\
}

#define ISCSI_PARAM_INIT (struct session_param) {			\
	.flags			= SESSION_FLG_INITIAL_R2T		\
		 		| SESSION_FLG_IMMEDIATE_DATA		\
		 		| SESSION_FLG_DATA_PDU_INORDER		\
		 		| SESSION_FLG_DATA_SEQUENCE_INORDER,	\
	.max_connections 	= 1,					\
	.max_data_pdu_length 	= 8192,					\
	.max_burst_length 	= 262144,				\
	.first_burst_length 	= 65536,				\
	.default_wait_time 	= 2,					\
	.default_retain_time 	= 20,					\
	.max_outstanding_r2t 	= 1,					\
	.error_recovery_level 	= 0,					\
	.header_digest	 	= 0,					\
	.data_digest	 	= 0,					\
	.max_sessions	 	= 0,					\
}

enum {
	key_max_connections,
	key_initial_r2t,
	key_immediate_data,
	key_max_data_pdu_length,
	key_max_burst_length,
	key_first_burst_length,
	key_default_wait_time,
	key_default_retain_time,
	key_max_outstanding_r2t,
	key_data_pdu_inorder,
	key_data_sequence_inorder,
	key_error_recovery_level,
	key_header_digest,
	key_data_digest,
	key_last
};

#define KEY_STATE_START		0
#define KEY_STATE_REQUEST	1
#define KEY_STATE_DONE		2

struct session {
	struct session *next;
	struct target *target;

	char *initiator;
	union iscsi_sid sid;

	int conn_cnt;
};

#define CHAP_CHALLENGE_MAX	50

#define HEX_FORMAT	0x01
#define BASE64_FORMAT 0x02

struct connection {
	int state;
	int iostate;
	int fd;

	//struct connection *next;
	struct session *session;

	struct target *target;
	struct session_param param;

	char *initiator;
	union iscsi_sid sid;
	u16 cid;
	u16 pad;
	int session_type;
	int auth_method;
	int header_digest;
	int data_digest;

	u32 stat_sn;
	u32 exp_stat_sn;

	u32 cmd_sn;
	u32 exp_cmd_sn;
	u32 max_cmd_sn;

	struct PDU req;
	void *req_buffer;
	struct PDU rsp;
	void *rsp_buffer;
	unsigned char *buffer;
	int rwsize;

	int key_state[key_last];

	int auth_state;
	union {
		struct {
			int digest_alg;
			int id;
			int challenge_size;
			char *challenge;
		} chap;
	} auth;
};

#define IOSTATE_FREE		0
#define IOSTATE_READ_BHS	1
#define IOSTATE_READ_AHS_DATA	2
#define IOSTATE_WRITE_BHS	3
#define IOSTATE_WRITE_AHS	4
#define IOSTATE_WRITE_DATA	5

#define STATE_FREE		0
#define STATE_SECURITY		1
#define STATE_SECURITY_AUTH	2
#define STATE_SECURITY_DONE	3
#define STATE_SECURITY_LOGIN	4
#define STATE_SECURITY_FULL	5
#define STATE_LOGIN		6
#define STATE_LOGIN_FULL	7
#define STATE_FULL		8
#define STATE_KERNEL		9
#define STATE_CLOSE		10
#define STATE_EXIT		11

#define AUTH_STATE_START	0
#define AUTH_STATE_CHALLENGE	1

#define AUTH_DIR_INCOMING       0
#define AUTH_DIR_OUTGOING       1

#define SESSION_NORMAL		0
#define SESSION_DISCOVERY	1
#define AUTH_UNKNOWN		-1
#define AUTH_NONE		0
#define AUTH_CHAP		1
#define DIGEST_UNKNOWN		-1
#define DIGEST_NONE		0
#define DIGEST_CRC32C           1

#define BHS_SIZE		48

#define INCOMING_BUFSIZE	8192

/* isns */
struct storage_node;

struct target {
	struct target *next;

	struct session *sessions;
	int session_cnt;

	struct target_volume *volumes;

	u32 id;
	char *name;
	char *alias;
	struct user *users_in;
	struct user *user_out;

	u32 nr_wthreads;
	u32 type;

	struct storage_node *isns_node;

	struct session_param default_param;
};

struct target_volume {
	struct target_volume *next;

	int lun;

	char *path;
	char *mode;
};

struct user {
	struct user *next;
	char *name;
	char *password;
};

/* chap.c */
extern int cmnd_exec_auth_chap(struct connection *conn);

/* conn.c */
extern struct connection *conn_alloc(void);
extern void conn_free(struct connection *conn);
extern int conn_test(struct connection *conn);
extern void conn_take_fd(struct connection *conn, int fd);
extern void conn_read_pdu(struct connection *conn);
extern void conn_write_pdu(struct connection *conn);
extern void conn_free_pdu(struct connection *conn);

/* iscsid.c */
extern struct user *iscsi_discovery_users_in;
extern struct user *iscsi_discovery_user_out;
extern int iscsi_debug;

extern int cmnd_execute(struct connection *conn);
extern void cmnd_finish(struct connection *conn);
extern char *text_key_find(struct connection *conn, char *searchKey);
extern void text_key_add(struct connection *conn, char *key, char *value);

/* log.c */
extern int log_daemon;
extern int log_level;

extern void log_init(void);
extern void log_warning(const char *fmt, ...)
	__attribute__ ((format (printf, 1, 2)));
extern void log_error(const char *fmt, ...)
	__attribute__ ((format (printf, 1, 2)));
extern void log_debug(int level, const char *fmt, ...)
	__attribute__ ((format (printf, 2, 3)));
extern void log_pdu(int level, struct PDU *pdu);

/* session.c */
extern struct session *session_alloc(struct target *target);
extern struct session *session_find_name(struct target *target, const char *iname, union iscsi_sid sid);
extern struct session *session_find_id(struct target *target, u64 sid);
extern void session_create(struct connection *conn);
extern void session_remove(struct session *session);

/* target.c */
extern struct target *targets;
extern void config_scan(char *config);
extern struct target *target_find_name(const char *name);
extern struct target *target_find_id(u32 id);
extern struct target * target_alloc(u32 id, char *name);
extern int target_add(int ctrl_fd, u32 tid);
extern int target_start(int ctrl_fd, u32 tid);
extern int user_add(u32 tid, char *name, char *pass, int global, int auth_dir);

/* main.c */
void *xmalloc(size_t);

/* message.c */
extern int ietadm_request_listen(void);
extern int ietadm_request_handle(int accept_fd);

/* ctldev.c */
extern int ctrdev_open(void);
extern int volume_add(int fd, u32 tid, u32 lun, char *path, char *iomode);
extern int server_stop(void);
extern int conn_close(int fd, u32 tid, u64 sid, u32 cid);
extern int session_conns_close(u32 tid, u64 sid);

/* isns.c */
struct tag_len_val;
struct network_entity;
extern int initialize_iet_isns(char *isnsip, int port);
extern void cleanup_iet_isns(void);
extern struct storage_node *initialize_storage_node(char *name, char *alias);
extern void cleanup_storage_node(struct storage_node *node);
extern int RegNode(struct storage_node *node);
extern int DeRegNode(struct storage_node *node);
extern int use_isns;
extern int get_portal_address(char *ip);
extern int DeRegEntity(struct network_entity *entity, struct tag_len_val *name);

extern int ctrl_fd;

#define version()							\
do {									\
	printf("%s version %s\n", program_name, IET_VERSION_STRING);	\
	exit(0);							\
} while (0)

#endif	/* ISCSID_H */
