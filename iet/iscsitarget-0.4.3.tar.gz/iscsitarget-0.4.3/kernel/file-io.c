/*
 * Target device file I/O.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/blkdev.h>
#include <linux/writeback.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"
#include "iotype.h"

MODULE_AUTHOR("Fujita Tomonori <tomof@acm.org>");
MODULE_DESCRIPTION("iSCSI Target file I/O");
MODULE_LICENSE("GPL");

struct fileio_data {
	struct file *filp;
};

int fileio_make_request(struct iet_volume *lu, struct target_cmnd *tcmnd, int rw)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;
	struct file *filp;
	mm_segment_t oldfs;
	struct page *page;
	u32 offset, size;
	loff_t ppos, count;
	char *buf;
	int i;
	ssize_t ret;

	assert(p);
	filp = p->filp;
	size = tcmnd->size;
	offset= tcmnd->offset;

	ppos = (loff_t) tcmnd->idx << PAGE_CACHE_SHIFT;
	ppos += offset;

	for (i = 0; i < tcmnd->pg_cnt; i++) {
		page = tcmnd->pvec[i];
		assert(page);
		buf = page_address(page);
		buf += offset;

		if (offset + size > PAGE_SIZE)
			count = PAGE_SIZE - offset;
		else
			count = size;

		oldfs = get_fs();
		set_fs(get_ds());

		if (rw == READ)
			ret = generic_file_read(filp, buf, count, &ppos);
		else
			ret = generic_file_write(filp, buf, count, &ppos);

		set_fs(oldfs);

		if (ret != count)
			eprintk("I/O error %lld, %ld\n", count, (long) ret);

		size -= count;
		offset = 0;
	}
	assert(!size);

	return 0;
}

int fileio_sync(struct iet_volume *lu, struct target_cmnd *tcmnd)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;
	struct inode *inode;
	loff_t ppos = (loff_t) tcmnd->idx << PAGE_CACHE_SHIFT;
	ssize_t res;

	assert(p);
	inode = p->filp->f_dentry->d_inode;

	res = sync_page_range(inode, inode->i_mapping, ppos, (size_t) tcmnd->size);

	return 0;
}

int fileio_attach(struct iet_volume *lu, char *path)
{
	int res = 0;
	struct fileio_data *p;
	struct file *filp;
	mm_segment_t oldfs;
	struct inode *inode;

	if (lu->private) {
		printk("already attached ? %d\n", lu->lun);
		return -EBUSY;
	}

	if ((p = kmalloc(sizeof(*p), GFP_KERNEL)) == NULL)
		return -ENOMEM;

	oldfs = get_fs();
	set_fs(get_ds());
	filp = filp_open(path, O_RDWR|O_LARGEFILE, 0);
	set_fs(oldfs);
	if (IS_ERR(filp)) {
		res = PTR_ERR(filp);
		eprintk("We can't open %s %d\n", path, res);
		goto fail;
	}

	inode = filp->f_dentry->d_inode;
	if (S_ISREG(inode->i_mode)) {
		/* nothing to do */
	} else if (S_ISBLK(inode->i_mode)) {
		inode = inode->i_bdev->bd_inode;
	} else {
		eprintk("%s is not a block file %x\n", path, inode->i_mode);
		filp_close(filp, NULL);
		res = -EINVAL;
		goto fail;
	}

	lu->blk_shift = SECTOR_SIZE_BITS;
	lu->blk_cnt = inode->i_size >> lu->blk_shift;

	p->filp = filp;

	lu->private = p;

	return res;
fail:
	kfree(p);
	return res;
}

void fileio_detach(struct iet_volume *lu)
{
	struct fileio_data *p = (struct fileio_data *) lu->private;

	assert(p);
	filp_close(p->filp, NULL);
	kfree(p);
	lu->private = NULL;
}

struct iotype fileio =
{
	.name = "fileio",
	.attach = fileio_attach,
	.make_request = fileio_make_request,
	.sync = fileio_sync,
	.detach = fileio_detach,
};
