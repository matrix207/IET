/*
 * Worker thread.
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include <linux/kthread.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"

void queue_cmnd(struct iscsi_cmnd *cmnd, nio_func_t *nio)
{
	struct worker_thread_info *info = &cmnd->conn->session->target->wthread_info;

	assert(list_empty(&cmnd->list));
	add_cmnd_nio(cmnd, nio);
	cmnd->state = ISCSI_STATE_QUEUED;

	spin_lock(&info->wthread_lock);
	list_add_tail(&cmnd->list, &info->work_queue);
	spin_unlock(&info->wthread_lock);

	wake_up(&info->wthread_sleep);
}

static struct iscsi_cmnd * get_ready_cmnd(struct worker_thread_info *info)
{
	struct iscsi_cmnd *cmnd = NULL;

	spin_lock(&info->wthread_lock);
	if (!list_empty(&info->work_queue)) {
		cmnd = list_entry(info->work_queue.next, struct iscsi_cmnd, list);
		list_del_init(&cmnd->list);

		assert(cmnd->conn);
		atomic_inc(&cmnd->conn->nr_busy_cmnds);
		assert(cmnd->nio_idx);
	}
	spin_unlock(&info->wthread_lock);

	return cmnd;
}

static int worker_thread(void *arg)
{
	struct worker_thread_info *info = (struct worker_thread_info *) arg;
	struct iscsi_cmnd *cmnd;
	DECLARE_WAITQUEUE(wait, current);

	add_wait_queue(&info->wthread_sleep, &wait);

	__set_current_state(TASK_RUNNING);
	do {
		while ((cmnd = get_ready_cmnd(info)) != NULL) {
			struct iscsi_conn *conn = cmnd->conn;
			while (cmnd->nio_idx)
				exec_cmnd_nio(cmnd);

			assert(conn);
			atomic_dec(&conn->nr_busy_cmnds);
		}

		if (!list_empty(&info->work_queue))
			continue;

		__set_current_state(TASK_INTERRUPTIBLE);
		if (list_empty(&info->work_queue))
			schedule();

		__set_current_state(TASK_RUNNING);
	} while (!kthread_should_stop());

	remove_wait_queue(&info->wthread_sleep, &wait);

	return 0;
}

static int start_one_worker_thread(struct iscsi_target *target)
{
	struct worker_thread_info *info = &target->wthread_info;
	struct worker_thread *wt;
	struct task_struct *task;

	if ((wt = kmalloc(sizeof(struct worker_thread), GFP_KERNEL)) == NULL)
		return -ENOMEM;

	task = kthread_run(worker_thread, info, "istiod%d", target->tid);
	if (IS_ERR(task)) {
		kfree(wt);
		return PTR_ERR(task);
	}

	wt->w_task = task;
	list_add(&wt->w_list, &info->wthread_list);

	return 0;
}

static int stop_one_worker_thread(struct worker_thread *wt)
{
	int err;

	assert(wt->w_task);
	if ((err = kthread_stop(wt->w_task)) < 0)
		return err;

	list_del(&wt->w_list);
	kfree(wt);

	return 0;
}

int worker_thread_init(struct iscsi_target *target)
{
	struct worker_thread_info *info = &target->wthread_info;

	spin_lock_init(&info->wthread_lock);

	info->nr_running_wthread = 0;

	INIT_LIST_HEAD(&info->work_queue);
	INIT_LIST_HEAD(&info->wthread_list);

	init_waitqueue_head(&info->wthread_sleep);

	return 0;
}

int worker_thread_start(struct iscsi_target *target)
{
	int err = 0;
	struct worker_thread_info *info = &target->wthread_info;

	while (info->nr_running_wthread < info->nr_wthread) {
		err = start_one_worker_thread(target);
		if (err < 0) {
			eprintk("Fail to create a worker thread %d\n", err);
			break;
		}

		info->nr_running_wthread++;
	}

	return err;
}

int worker_thread_stop(struct iscsi_target *target)
{
	struct worker_thread *wt, *tmp;
	int err = 0;
	struct worker_thread_info *info = &target->wthread_info;

	list_for_each_entry_safe(wt, tmp, &info->wthread_list, w_list) {
		if ((err = stop_one_worker_thread(wt)) < 0) {
			eprintk("Fail to stop a worker thread %d\n", err);
			return err;
		}

		info->nr_running_wthread--;
	}

	return err;
}
