/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/file.h>
#include <linux/ip.h>
#include <net/tcp.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"
#include "digest.h"

void print_conn_state(struct seq_file *seq, unsigned long state)
{
	if (test_bit(CONN_NEW, &state))
		seq_printf(seq, "%s", "new");
	else if (test_bit(CONN_ACTIVE, &state))
		seq_printf(seq, "%s", "active");
	else if (test_bit(CONN_CLOSING, &state))
		seq_printf(seq, "%s", "closing");
	else
		seq_printf(seq, "%s", "unknown");
}

#define addr(ip, shift) ((htonl(ip) >> shift) & 0xff)

void conns_info_show(struct seq_file *seq, struct iscsi_session *session)
{
	struct iscsi_conn *conn;
	unsigned int dest;
	list_for_each_entry(conn, &session->conn_list, list) {
		dest = inet_sk(conn->sock->sk)->daddr;
		seq_printf(seq, "\t\tcid:%u ip:%u.%u.%u.%u state:", conn->cid,
			   addr(dest,24), addr(dest,16), addr(dest, 8), addr(dest, 0));
		print_conn_state(seq, conn->state);
		seq_printf(seq, " hd: %d dd: %d\n", conn->hdigest_type, conn->ddigest_type);
	}
}

struct iscsi_conn *iet_conn_lookup(struct iscsi_session *session, u16 cid)
{
	struct iscsi_conn *conn;

	list_for_each_entry(conn, &session->conn_list, list) {
		if (conn->cid == cid)
			return conn;
	}
	return NULL;
}

static void iet_state_change(struct sock *sk)
{
	struct iscsi_conn *conn = sk->sk_user_data;
	struct iscsi_target *target = conn->session->target;

	if (sk->sk_state != TCP_ESTABLISHED)
		iet_conn_close(conn);
	else
		wake_up_nthread(target);

	target->nthread_info.old_state_change(sk);
}

static void iet_data_ready(struct sock *sk, int len)
{
	struct iscsi_conn *conn = sk->sk_user_data;
	struct iscsi_target *target = conn->session->target;

	wake_up_nthread(target);
	target->nthread_info.old_data_ready(sk, len);
}

static void iet_socket_bind(struct iscsi_conn *conn)
{
	int opt = 1;
	mm_segment_t oldfs;
	struct iscsi_session *session = conn->session;
	struct iscsi_target *target = session->target;

	dprintk(D_GENERIC, "%llu\n", (unsigned long long) session->sid);

	conn->sock = SOCKET_I(conn->file->f_dentry->d_inode);
	conn->sock->sk->sk_user_data = conn;

	write_lock(&conn->sock->sk->sk_callback_lock);
	target->nthread_info.old_state_change = conn->sock->sk->sk_state_change;
	conn->sock->sk->sk_state_change = iet_state_change;

	target->nthread_info.old_data_ready = conn->sock->sk->sk_data_ready;
	conn->sock->sk->sk_data_ready = iet_data_ready;
	write_unlock(&conn->sock->sk->sk_callback_lock);

	oldfs = get_fs();
	set_fs(get_ds());
	conn->sock->ops->setsockopt(conn->sock, SOL_TCP, TCP_NODELAY, (void *)&opt, sizeof(opt));
	set_fs(oldfs);
}

int iet_conn_free(struct iscsi_conn *conn)
{
	dprintk(D_GENERIC, "%p %#Lx %u\n", conn->session,
		(unsigned long long) conn->session->sid, conn->cid);

	assert(atomic_read(&conn->nr_cmnds) == 0);
	assert(list_empty(&conn->pdu_list));
	assert(list_empty(&conn->write_list));

	list_del(&conn->list);
	list_del(&conn->poll_list);

	digest_cleanup(conn);
	kfree(conn);

	return 0;
}

static int iet_conn_alloc(struct iscsi_session *session, struct conn_info *info)
{
	struct iscsi_conn *conn;

	dprintk(D_SETUP, "%#Lx:%u\n", (unsigned long long) session->sid, info->cid);

	if (!iet_is_target_running(session->target)) {
		eprintk("Target (%u) doesn't run", session->target->tid);
		return -EIO;
	}

	conn = kmalloc(sizeof(*conn), GFP_KERNEL);
	if (!conn)
		return -ENOMEM;
	memset(conn, 0, sizeof(*conn));

	set_bit(CONN_NEW, &conn->state);
	conn->session = session;
	conn->cid = info->cid;
	conn->stat_sn = info->stat_sn;
	conn->exp_stat_sn = info->exp_stat_sn;

	conn->hdigest_type = info->header_digest;
	conn->ddigest_type = info->data_digest;
	if (digest_init(conn) < 0) {
		kfree(conn);
		return -ENOMEM;
	}

	spin_lock_init(&conn->list_lock);
	atomic_set(&conn->nr_cmnds, 0);
	atomic_set(&conn->nr_busy_cmnds, 0);
	INIT_LIST_HEAD(&conn->pdu_list);
	INIT_LIST_HEAD(&conn->write_list);
	INIT_LIST_HEAD(&conn->poll_list);

	list_add(&conn->list, &session->conn_list);

	set_bit(CONN_ACTIVE, &conn->state);

	conn->file = fget(info->fd);
	iet_socket_bind(conn);

	list_add(&conn->poll_list, &session->target->nthread_info.active_conns);

	wake_up_nthread(conn->session->target);

	return 0;
}

int iet_conn_add(struct iscsi_session *session, struct conn_info *info)
{
	struct iscsi_conn *conn;
	int res = -EEXIST;

	conn = iet_conn_lookup(session, info->cid);
	if (conn)
		return res;

	return iet_conn_alloc(session, info);
}

void iet_conn_close(struct iscsi_conn *conn)
{
	if (test_and_clear_bit(CONN_ACTIVE, &conn->state))
		set_bit(CONN_CLOSING, &conn->state);

	wake_up_nthread(conn->session->target);
}

int iet_conn_del(struct iscsi_session *session, struct conn_info *info)
{
	struct iscsi_conn *conn;
	int res = -EEXIST;

	conn = iet_conn_lookup(session, info->cid);
	if (!conn)
		return res;

	iet_conn_close(conn);

	return 0;
}
