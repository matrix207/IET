/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#ifndef __TARGET_H__
#define __TARGET_H__

struct target_cmnd {
	u32 pg_cnt;

	unsigned long idx;
	u32 offset;
	u32 size;

	struct page **pvec;
};

extern struct target_cmnd *target_cmnd_alloc(void);
extern int target_alloc_pages(struct target_cmnd *cmnd, int count);
extern void target_free_pages(struct target_cmnd *cmnd);
extern void target_init_iocmnd(struct target_cmnd *tcmnd, loff_t offset, u32 size);

extern int target_init(void);
extern void target_exit(void);

extern struct iotype *get_iotype(const char *name);
extern void put_iotype(struct iotype *iot);

#endif	/* __TARGET_H__ */
