/*
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

#include <linux/proc_fs.h>

#include "iscsi.h"
#include "iscsi_dbg.h"

struct proc_entries {
	const char *name;
	struct file_operations *fops;
};

static struct proc_entries iet_proc_entries[] =
{
	{"volume", &volume_seq_fops},
	{"session", &session_seq_fops},
};

static struct proc_dir_entry *proc_iet_dir;

void iet_procfs_init(void)
{
	int i;
	struct proc_dir_entry *ent;

	if ((proc_iet_dir = proc_mkdir("net/iet", 0)) == NULL)
		return;

	proc_iet_dir->owner = THIS_MODULE;

	for (i = 0; i < ARRAY_SIZE(iet_proc_entries); i++) {
		ent = create_proc_entry(iet_proc_entries[i].name, 0, proc_iet_dir);
		if (ent)
			ent->proc_fops = iet_proc_entries[i].fops;
	}
}

void iet_procfs_exit(void)
{
	int i;

	if (!proc_iet_dir)
		return;

	for (i = 0; i < ARRAY_SIZE(iet_proc_entries); i++)
		remove_proc_entry(iet_proc_entries[i].name, proc_iet_dir);

	remove_proc_entry(proc_iet_dir->name, proc_iet_dir->parent);
}


static spinlock_t event_queue_lock = SPIN_LOCK_UNLOCKED;
static LIST_HEAD(event_queue);
DECLARE_WAIT_QUEUE_HEAD(event_wait);

struct kevent *iet_event_get(int del)
{
	struct kevent *kevent = ERR_PTR(-EAGAIN);

	spin_lock(&event_queue_lock);
	if (list_empty(&event_queue))
		goto out;

	kevent = list_entry(event_queue.next, struct kevent, list);
	if (del)
		list_del(&kevent->list);
out:
	spin_unlock(&event_queue_lock);

	return kevent;
}

int iet_event_put(u32 tid, u64 sid, u32 cid, u32 state, int atomic)
{
	struct kevent *kevent;

	if (atomic) {
		kevent = kmalloc(sizeof(*kevent), GFP_ATOMIC);
		if (!kevent)
			return -ENOMEM;
	} else {
		do {
			kevent = kmalloc(sizeof(*kevent), GFP_KERNEL);
			if (!kevent)
				yield();
		} while (!kevent);
	}

	memset(kevent, 0, sizeof(*kevent));
	INIT_LIST_HEAD(&kevent->list);

	kevent->ev.tid = tid;
	kevent->ev.sid = sid;
	kevent->ev.cid = cid;
	kevent->ev.state = state;

	spin_lock(&event_queue_lock);
	list_add(&kevent->list, &event_queue);
	spin_unlock(&event_queue_lock);

	return 0;
}

static ssize_t read(struct file *file, char *buf, size_t count, loff_t *ppos)
{
	struct kevent *kevent;

	if (count != sizeof(struct iet_event))
		return -EIO;

	kevent = iet_event_get(1);
	if (IS_ERR(kevent))
		return -EAGAIN;

	if (copy_to_user(buf, &kevent->ev, count))
		count = -EFAULT;

	kfree(kevent);

	return count;
}

static int open(struct inode *inode, struct file *file)
{
	return 0;
}

static int close(struct inode *inode, struct file *file)
{
	return 0;
}

static unsigned int poll(struct file *filp, poll_table *wait)
{
	poll_wait(filp, &event_wait, wait);

	return IS_ERR(iet_event_get(0)) ? 0 : POLLIN | POLLRDNORM;
}

static int get_conn_info(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct iscsi_session *session;
	struct conn_info info;
	struct iscsi_conn *conn;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	session = iet_session_lookup(target, info.sid);
	if (!session)
		return -ENOENT;
	conn = iet_conn_lookup(session, info.cid);

	info.cid = conn->cid;
	info.stat_sn = conn->stat_sn;
	info.exp_stat_sn = conn->exp_stat_sn;

	if (copy_to_user((void *) ptr, &info, sizeof(info)))
		return -EFAULT;

	return 0;
}

static int add_conn(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct iscsi_session *session;
	struct conn_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	if ((session = iet_session_lookup(target, info.sid)) == NULL)
		return -ENOENT;

	return iet_conn_add(session, &info);
}

static int del_conn(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct iscsi_session *session;
	struct conn_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	if ((session = iet_session_lookup(target, info.sid)) == NULL)
		return -ENOENT;

	return iet_conn_del(session, &info);
}

static int get_session_info(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct iscsi_session *session;
	struct session_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	session = iet_session_lookup(target, info.sid);

	if (!session)
		return -ENOENT;

	info.exp_cmd_sn = session->exp_cmd_sn;
	info.max_cmd_sn = session->max_cmd_sn;

	if (copy_to_user((void *) ptr, &info, sizeof(info)))
		return -EFAULT;

	return 0;
}

static int add_session(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct session_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	return iet_session_add(target, &info);
}

static int del_session(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct session_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	return iet_session_del(target, &info);
}

static int add_volume(struct iscsi_target *target, unsigned long ptr)
{
	int res;
	struct volume_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	return iet_volume_add(target, &info);
}

static int iscsi_param_get(struct iscsi_target *target, unsigned long ptr)
{
	int err;
	struct param_info info;

	if ((err = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return err;

	if ((err = iet_target_param_get(target, &info)) < 0)
		return err;

	if (copy_to_user((void *) ptr, &info, sizeof(info)))
		return -EFAULT;

	return 0;
}

static int iscsi_param_set(struct iscsi_target *target, unsigned long ptr)
{
	int err;
	struct param_info info;
	struct iscsi_session *session;

	if ((err = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return err;

	if (info.is_target_param)
		err = iet_target_param_set(target, &info);
	else {
		if ((session = iet_session_lookup(target, info.sid)) == NULL)
			err = -ENOENT;
		else
			err = iet_session_param_set(session, &info);
	}

	return err;
}

static int start_target(struct iscsi_target *target)
{
	return iet_target_start(target);
}

static int add_target(unsigned long ptr)
{
	int res;
	struct target_info info;

	if ((res = copy_from_user(&info, (void *) ptr, sizeof(info))) < 0)
		return res;

	return iet_target_add(&info);
}

static int ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct iscsi_target *target = NULL;
	int res;
	u32 id;

	if ((res = get_user(id, (u32 *) arg)) != 0)
		goto abort;

	target = iet_target_lookup(id);

	if (cmd == ADD_TARGET)
		if (target) {
			res = -EEXIST;
			eprintk("Target %u already exist!\n", id);
			goto abort;
		}

	if (cmd == DEL_TARGET) {
		if (!target) {
			res = -ENOENT;
			eprintk("Target %u does not exist!\n", id);
			goto abort;
		}

		res = iet_target_del(id);
		goto done;
	}

	switch (cmd) {
	case ADD_TARGET:

		assert(!target);

		res = add_target(arg);

		goto done;
	}

	if (!target) {
		eprintk("can't find the target %u\n", id);
		res = -EINVAL;
		goto abort;
	}

	res = iet_target_lock(target, 1);
	if (res < 0) {
		eprintk("interrupted %d %d\n", res, cmd);
		goto abort;
	}

	switch (cmd) {
	case START_TARGET:
		res = start_target(target);
		break;

	case ADD_VOLUME:
		res = add_volume(target, arg);
		break;

	case ADD_SESSION:
		res = add_session(target, arg);
		break;

	case DEL_SESSION:
		res = del_session(target, arg);
		break;

	case GET_SESSION_INFO:
		res = get_session_info(target, arg);
		break;

	case ISCSI_PARAM_SET:
		res = iscsi_param_set(target, arg);
		break;

	case ISCSI_PARAM_GET:
		res = iscsi_param_get(target, arg);
		break;

	case ADD_CONN:
		res = add_conn(target, arg);
		break;

	case DEL_CONN:
		res = del_conn(target, arg);
		break;

	case GET_CONN_INFO:
		res = get_conn_info(target, arg);
		break;

	}

	if (target)
		iet_target_unlock(target);

done:
abort:
	return res;
}

struct file_operations ctr_fops = {
	.owner		= THIS_MODULE,
	.open		= open,
	.ioctl		= ioctl,
	.poll		= poll,
	.read		= read,
	.release	= close,
};
