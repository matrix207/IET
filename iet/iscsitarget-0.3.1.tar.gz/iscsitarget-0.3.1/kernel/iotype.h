/*
 * (C) 2004 Fujita Tomonori <tomof@acm.org>
 * This code is licenced under the GPL.
 */

#include "iscsi.h"

#ifndef __IOTYPE_H__
#define __IOTYPE_H__

struct iotype {
	const char *name;
	struct module *owner;
	struct list_head iot_list;

	int (*attach)(struct iet_volume *dev, char *path);
	int (*make_request)(struct iet_volume *dev, struct target_cmnd *tcmnd, int rw);
	int (*sync)(struct iet_volume *dev, struct target_cmnd *tcmnd);
	void (*detach)(struct iet_volume *dev);
};

extern int register_iotype(struct iotype *iot);
extern int unregister_iotype(struct iotype *iot);

#endif
