/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/slab.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/errno.h>

#include "iscsi.h"
#include "target.h"
#include "iscsi_dbg.h"

struct iscsi_session *iet_session_lookup(struct iscsi_target *target, u64 sid)
{
	struct iscsi_session *session;

	list_for_each_entry(session, &target->session_list, list) {
		if (session->sid == sid)
			return session;
	}
	return NULL;
}

static int iet_session_alloc(struct iscsi_target *target, struct session_info *info)
{
	int res;
	struct iscsi_session *session;

	dprintk(D_SETUP, "%p %u %#Lx\n", target, target->target.id, info->sid);
	session = kmalloc(sizeof(*session), GFP_KERNEL);
	if (!session)
		return -ENOMEM;
	memset(session, 0, sizeof(*session));

	session->target = target;
	session->sid = info->sid;
	memcpy(&session->param, &target->default_param, sizeof(session->param));

	session->exp_cmd_sn = info->exp_cmd_sn;
	session->max_cmd_sn = info->max_cmd_sn;

	session->initiator = kmalloc(sizeof(info->initiator_name), GFP_KERNEL);
	if (!session->initiator) {
		res = -ENOMEM;
		goto err;
	}
	memcpy(session->initiator, info->initiator_name, sizeof(info->initiator_name));

	INIT_LIST_HEAD(&session->conn_list);
	INIT_LIST_HEAD(&session->pending_list);
	spin_lock_init(&session->cmnd_tt_lock);
	session->next_ttt = 1;

	list_add(&session->list, &target->session_list);

	return 0;
err:
	if (session) {
		if (session->initiator)
			kfree(session->initiator);
		kfree(session);
	}
	return res;
}

int iet_session_add(struct iscsi_target *target, struct session_info *info)
{
	struct iscsi_session *session;
	int res = -EEXIST;

	session = iet_session_lookup(target, info->sid);
	if (session)
		return res;

	res = iet_session_alloc(target, info);

	return res;
}

int iet_session_free(struct iscsi_session *session)
{
	struct iscsi_cmnd *cmnd;
	int i;

	dprintk(D_SETUP, "%#Lx\n", session->sid);

	assert(list_empty(&session->conn_list));

	for (i = 0; i < ISCSI_TT_HASHSIZE; i++) {
		while ((cmnd = session->cmnd_itt_hash[i])) {
			eprintk("cmnd %p %d %x\n", cmnd, cmnd->state, cmnd_opcode(cmnd));
			BUG();
		}
	}

	for (i = 0; i < ISCSI_TT_HASHSIZE; i++) {
		while ((cmnd = session->cmnd_ttt_hash[i])) {
			eprintk("cmnd %p %d %x\n", cmnd, cmnd->state, cmnd_opcode(cmnd));
			BUG();
		}
	}

	list_del(&session->list);

	kfree(session->initiator);
	kfree(session);

	return 0;
}

int iet_session_del(struct iscsi_target *target, struct session_info *info)
{
	struct iscsi_session *session;

	session = iet_session_lookup(target, info->sid);
	if (!session)
		return -ENOENT;

	if (!list_empty(&session->conn_list)) {
		eprintk("%llu still have connections\n", session->sid);
		return -EBUSY;
	}

	return iet_session_free(session);
}

static void iet_session_info_show(struct seq_file *seq, struct iscsi_target *target)
{
	struct iscsi_session *session;

	list_for_each_entry(session, &target->session_list, list) {
		seq_printf(seq, "\tsid:%llu initiator:%s\n",
			   session->sid, session->initiator);
		conns_info_show(seq, session);
	}
}

static int iet_sessions_info_show(struct seq_file *seq, void *v)
{
	return iet_info_show(seq, iet_session_info_show);
}

static int iet_session_seq_open(struct inode *inode, struct file *file)
{
	return single_open(file, iet_sessions_info_show, NULL);
}

struct file_operations session_seq_fops = {
	.owner		= THIS_MODULE,
	.open		= iet_session_seq_open,
	.read		= seq_read,
	.llseek		= seq_lseek,
	.release	= single_release,
};
