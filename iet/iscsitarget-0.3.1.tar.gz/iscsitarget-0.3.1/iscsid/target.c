/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "iscsid.h"

static char default_iomode[] = "fileio";
struct target *targets;
struct device *devices;

int target_next_id = 0;
int device_next_id = 0;

static char *target_sep_string(char **pp)
{
	char *p = *pp;
	char *q;

	for (p = *pp; isspace(*p); p++)
		;
	for (q = p; *q && !isspace(*q); q++)
		;
	if (*q)
		*q++ = 0;
	else
		p = NULL;
	*pp = q;
	return p;
}

static void target_sep_bool(char **pp, u32 *flags, int mask)
{
	char *p;

	p = target_sep_string(pp);
	if (!p)
		return;
	switch (*p) {
	case 'y': case 'Y':
		*flags |= mask;
		break;
	case 'n': case 'N':
		*flags &= ~mask;
		break;
	}
}

static int target_add_volume(struct target *target, struct target_volume *volume)
{
	int res;
	struct volume_info info;

	memset(&info, 0, sizeof(info));

	info.tid = target->id;
	info.lun = volume->lun;
	info.major = major(volume->dev);
	info.minor = minor(volume->dev);

	strncpy(info.path, volume->path, sizeof(info.path));
	strncpy(info.mode, volume->mode, sizeof(info.mode));

	res = ioctl(ctrl_fd, ADD_VOLUME, &info);

	if (res < 0)
		fprintf(stderr, "can't add a volume %d %x %x", res, info.major, info.minor);

	return res;
}

static int target_add(struct target *target)
{
	int res;
	struct target_info info;

	memset(&info, 0, sizeof(info));

	info.tid = target->id;
	if (target->name == NULL)
		return -EINVAL;
	memcpy(info.name, target->name, sizeof(info.name) - 1);
	if (target->alias)
		memcpy(info.alias, target->alias, sizeof(info.alias) - 1);

	res = ioctl(ctrl_fd, ADD_TARGET, &info);
	if (res < 0) {
		fprintf(stderr, "can't create a target %d", res);
		return res;
	}

	return res;
}

#define BUFSIZE 4096

void target_scan(char *configfile)
{
	FILE *config;
	struct target *target;
	char buf[BUFSIZE];
	char *p, *q;
	int lun, skip;

	config = fopen(configfile, "r");
	if (!config)
		return;

	target = NULL;
	skip = 1;
	while (fgets(buf, BUFSIZE, config)) {
		q = buf;
		p = target_sep_string(&q);
		if (!p || *p == '#')
			continue;

		if (!strcmp(p, "Target")) {
			p = target_sep_string(&q);
			if (!p) {
				skip = 1;
				continue;
			}
			skip = 0;
			target = target_find_name(p);
			if (!target) {
				log_debug(1, "creaing target %u: %s", target_next_id, p);
				target = xmalloc(sizeof(*target));
				memset(target, 0, sizeof(*target));
				target->id = target_next_id++;
				target->name = strdup(p);
				param_set_linux_default(&target->default_param);
				target->nr_wthreads = 8;

				target->next = targets;
				target->volumes = NULL;
				targets = target;
			}
		} else if (!strcmp(p, "Alias")) {
			if (skip)
				continue;
			p = target_sep_string(&q);
			target->alias = strdup(p);
		} else if (!strcmp(p, "MaxConnections")) {
			if (skip)
				continue;
			target->default_param.max_connections = strtol(q, &q, 0);
		} else if (!strcmp(p, "InitialR2T")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_INITIAL_R2T);
		} else if (!strcmp(p, "ImmediateData")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_IMMEDIATE_DATA);
		} else if (!strcmp(p, "MaxRecvDataSegmentLength")) {
			if (skip)
				continue;
			target->default_param.max_data_pdu_length = strtol(q, &q, 0);
		} else if (!strcmp(p, "MaxBurstLength")) {
			if (skip)
				continue;
			target->default_param.max_burst_length = strtol(q, &q, 0);
		} else if (!strcmp(p, "FirstBurstLength")) {
			if (skip)
				continue;
			target->default_param.first_burst_length = strtol(q, &q, 0);
		} else if (!strcmp(p, "DefaultTime2Wait")) {
			if (skip)
				continue;
			target->default_param.default_wait_time = strtol(q, &q, 0);
		} else if (!strcmp(p, "DefaultTime2Retain")) {
			if (skip)
				continue;
			target->default_param.default_retain_time = strtol(q, &q, 0);
		} else if (!strcmp(p, "MaxOutstandingR2T")) {
			if (skip)
				continue;
			target->default_param.max_outstanding_r2t = strtol(q, &q, 0);
		} else if (!strcmp(p, "DataPDUInOrder")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_DATA_PDU_INORDER);
		} else if (!strcmp(p, "DataSequenceInOrder")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_DATA_SEQUENCE_INORDER);
		} else if (!strcmp(p, "ErrorRecoveryLevel")) {
			if (skip)
				continue;
		} else if (!strcmp(p, "Wthreads")) {
			if (skip)
				continue;
			target->nr_wthreads = strtol(q, &q, 0);
		} else if (!strcmp(p, "Lun")) {
			struct target_volume *volume;
			char *path, *mode;
			struct stat s;

			if (skip)
				continue;
			lun = strtol(q, &q, 10);

			path = target_sep_string(&q);
			mode = target_sep_string(&q);
			if (!p)
				;
			if (stat(path, &s))
				continue;

			volume = xmalloc(sizeof(*volume));
			volume->lun = lun;
			volume->path = strdup(path);
			if (mode)
				volume->mode = strdup(mode);
			else
				volume->mode = strdup(default_iomode);
			volume->dev = s.st_rdev;
			volume->next = target->volumes;

			target->volumes = volume;
		} else if (!strcmp(p, "User")) {
			struct user *user;
			char *name, *pass;

			name = target_sep_string(&q);
			pass = target_sep_string(&q);
			if (!name || !pass)
				continue;

			user = xmalloc(sizeof(*user) + strlen(name) + strlen(pass) + 2);
			user->name = (char *)user + sizeof(*user);
			user->password = user->name + strlen(name) + 1;
			strcpy(user->name, name);
			strcpy(user->password, pass);

			if (target) {
				user->next = target->users;
				target->users = user;
			} else {
				user->next = iscsi_discover_users;
				iscsi_discover_users = user;
			}
		}
	}
	fclose(config);

	for (target = targets; target; target = target->next) {
		struct target_volume *volume;

		if (!target->volumes) {
			log_warning("need to shutdown target %s", target->name);
			/* close all sessions */
			continue;
		}

		if (target_add(target) < 0) {
			log_warning("failed to add target %s", target->name);
			continue;
		}

		while (target->volumes) {
			volume = target->volumes;
			if (target_add_volume(target, volume) < 0)
				log_warning("failed to add volume%s", volume->path);

			target->volumes = volume->next;
			free(volume->path);
			free(volume->mode);
			free(volume);
		}

		/* FIXME: is this a good place to add this? */
		if (use_isns) {
			target->isns_node = initialize_storage_node(target->name, target->alias);
			RegNode(target->isns_node);
		}
	}
}

struct target *target_find_name(const char *name)
{
	struct target *target;

	log_debug(1, "target_find_name: %s", name);
	for (target = targets; target; target = target->next) {
		if (!strcmp(target->name, name))
			break;
	}
	return target;
}

struct target *target_find_id(u32 id)
{
	struct target *target;

	log_debug(1, "target_find_id: %u", id);
	for (target = targets; target; target = target->next) {
		if (target->id == id)
			break;
	}
	return target;
}

int target_remove(struct target *target)
{
	struct target **tp;
	DIR *dir;
	struct dirent *dirent;
	struct stat info;

	log_debug(1, "target_remove: %u,%s", target->id, target->name);
	target_set_path(target);
	strcat(procPath, "/lun");
	dir = opendir(procPath);
	if (!dir)
		goto out;

	while ((dirent = readdir(dir))) {
		if (!isdigit(dirent->d_name[0]))
			continue;
		target_set_path(target);
		proc_write("target", "device detach %u", atoi(dirent->d_name));
	}
	closedir(dir);

	strcpy(procPath, "/proc/iscsi");
	proc_write("iscsi", "target remove %u", target->id);

out:
	for (tp = &targets; *tp; tp = &(*tp)->next) {
		if (*tp == target) {
			*tp = target->next;
			break;
		}
	}
	target_set_path(target);
	free(target->name);
	free(target->alias);

	/* FIXME: is this a good place to add this? put in a signal handler
	 * will better i guess since the iscsid is always killed.
	 */
	if (use_isns) {
		DeRegNode(target->isns_node);
		cleanup_storage_node(target->isns_node);
	}

	free(target);
	return stat(procPath, &info) ? 0 : -1;
}

void target_set_path(struct target *target)
{
	sprintf(procPath, "%s/%u", PROC_TARGETDIR, target->id);
}
